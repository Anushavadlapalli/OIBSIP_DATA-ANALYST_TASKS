# OIBSIP — Oasis Infobyte SIP Virtual Internship Repository

![Track](https://img.shields.io/badge/Track-Python%20Programming-yellow.svg)
![Level](https://img.shields.io/badge/Tier-Advanced%20Completed-brightgreen.svg)
![Tasks](https://img.shields.io/badge/Tasks%20Completed-5%20of%205-blue.svg)
![Master](https://img.shields.io/badge/Launcher-1--Click%20GUI%20Suite-purple.svg)

---

## 📌 Repository Overview
Welcome to my official **OASIS INFOBYTE (OIBSIP)** internship repository for the **Python Programming** track.

This repository contains all **5 tasks** built to the **Advanced Tier** specification with modern graphical user interfaces (Tkinter), complete data persistence (SQLite3), mathematical & cryptographic security foundations, and an executive **Master Launcher GUI** that unifies all tasks under a single 1-click execution hub.

---

## 📁 Repository Directory Structure

Following the strict Oasis Infobyte SIP naming conventions:

```text
OIBSIP/
│
├── OIBSIP_Master_Launcher.py            # Central 1-Click GUI Executable for All Tasks
├── README.md                            # Master Repository Documentation
│
├── Python-Task1-VoiceAssistant/         # Task 1: AI Voice Assistant (Aura)
│   ├── voice_assistant.py               # Standalone Voice Assistant Application
│   ├── custom_commands.json             # Persistent Custom Trigger Rules
│   └── README.md                        # Task 1 Documentation & Demo Script
│
├── Python-Task2-BMICalculator/          # Task 2: Advanced BMI Calculator (BodyStat Pro)
│   ├── bmi_calculator.py                # Standalone BMI GUI & Analytics Application
│   ├── bmi_records.db                   # SQLite Database for Historical Records
│   └── README.md                        # Task 2 Documentation & Demo Script
│
├── Python-Task3-PasswordGenerator/      # Task 3: Cryptographic Password Suite (FortressPass)
│   ├── password_generator.py            # Standalone CSPRNG Generator Application
│   └── README.md                        # Task 3 Documentation & Demo Script
│
├── Python-Task4-WeatherApp/              # Task 4: Live Weather Forecasting (Atmosphere Pro)
│   ├── weather_app.py                   # Standalone Real-Time Weather Application
│   └── README.md                        # Task 4 Documentation & Demo Script
│
├── Python-Task5-ChatApplication/        # Task 5: Socket Chat Application (NexusChat)
│   ├── chat_app.py                      # 1-Click Suite Controller (Starts server + clients)
│   ├── server.py                        # Multi-Threaded TCP Socket Server
│   ├── client.py                        # Modern Socket Chat Client GUI
│   ├── chat_database.db                 # SQLite Database with SHA-256 Auth & History
│   └── README.md                        # Task 5 Documentation & Demo Script
│
└── zips/                                # Downloadable Individual & Combined Submission Packages
    ├── Task1_Voice_Assistant.zip
    ├── Task2_BMI_Calculator.zip
    ├── Task3_Password_Generator.zip
    ├── Task4_Weather_App.zip
    ├── Task5_Chat_Application.zip
    └── OIBSIP_Python_All_Tasks.zip
```

---

## 🚀 Master Execution — Run All Tasks

To launch the central interactive dashboard that can execute any task with 1 click and run system diagnostics:

```bash
python OIBSIP_Master_Launcher.py
```

---

## 🌟 Task Portfolio Summary

### 🎙️ Task 1: AI Voice Assistant (Aura)
- **Folder**: `Python-Task1-VoiceAssistant/`
- **Tech Stack**: Python, Tkinter, SAPI.SpVoice / pyttsx3, SpeechRecognition, Threading, JSON
- **Key Features**: Voice & typed command capture, zero-latency speech synthesis, dynamic animated audio waveform monitor, live weather reports, time/date, custom intent engine, and timed background reminders with audio popups.

### 📊 Task 2: BMI Calculator & Health Analytics (BodyStat Pro)
- **Folder**: `Python-Task2-BMICalculator/`
- **Tech Stack**: Python, Tkinter, Matplotlib, SQLite3, CSV
- **Key Features**: Dual Unit support (Metric & Imperial), WHO standard health classification, dynamic visual progress gauge, multi-user profiles, SQLite persistence, embedded interactive Matplotlib trend line chart, and CSV export.

### 🛡️ Task 3: Random Password Generator (FortressPass)
- **Folder**: `Python-Task3-PasswordGenerator/`
- **Tech Stack**: Python, secrets module (CSPRNG), Tkinter, Shannon Entropy
- **Key Features**: Cryptographically secure random generation using OS entropy (`secrets`), slider for 8-64 characters, guaranteed character type distribution, ambiguous character exclusion filter, real-time Shannon entropy meter, in-memory session history, and XKCD passphrase mode.

### 🌤️ Task 4: Real-Time Weather App (Atmosphere Pro)
- **Folder**: `Python-Task4-WeatherApp/`
- **Tech Stack**: Python, Tkinter, Open-Meteo REST API, IP Geolocation, JSON
- **Key Features**: Global city & ZIP code lookup, automatic IP-based location detection, instantaneous °C / °F unit toggle switch, 6-hour hourly projection cards, 5-day daily forecast table, atmospheric conditions grid, and in-GUI error messaging with zero API key requirement.

### 💬 Task 5: Real-Time Multi-Room Socket Chat (NexusChat)
- **Folder**: `Python-Task5-ChatApplication/`
- **Tech Stack**: Python, TCP Sockets, Multi-Threading, Tkinter, SQLite3, SHA-256
- **Key Features**: Multi-client concurrent TCP server on localhost, user authentication with SHA-256 password hashing, multi-room channels (`#general`, `#tech-talk`, `#oasis-interns`), historical message recovery, live online users sidebar, emoji shortcodes & toolbar, and 1-click dual-client test launcher.

---

## 📹 Video Submission Guidelines Checklist
- [x] Every task includes a dedicated walkthrough script in its `README.md`.
- [x] Initial 2-second static title card displaying:
  1. Full Name
  2. Assigned Track: **Python Programming**
  3. Task Title
- [x] End-to-end functionality shown (no static slides).

---

## 💼 LinkedIn Post Templates
Each task directory includes a pre-formatted, professional LinkedIn post template ready to copy and paste with proper hashtags (`#oasisinfobyte`, `#internship`, `#python`, etc.) and Oasis Infobyte tagging.

---

## 👨‍💻 Author
- **Internship**: Oasis Infobyte SIP (Python Programming Track)
- **Repository**: [OIBSIP on GitHub](https://github.com/YOUR_USERNAME/OIBSIP)
