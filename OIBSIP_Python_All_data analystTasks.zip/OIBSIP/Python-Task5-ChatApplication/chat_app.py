"""
Oasis Infobyte Internship - Task 5: Chat Application Master Runner
Author: OIBSIP Intern
Provides a 1-click launcher for:
1. Local Multi-threaded Chat Server (server.py)
2. Interactive Chat Client (client.py)
3. Launch 2 Clients simultaneously to test real-time two-way messaging on localhost
"""

import sys
import os
import subprocess
import time
import tkinter as tk
from tkinter import ttk, messagebox

DIR_PATH = os.path.dirname(os.path.abspath(__file__))
SERVER_SCRIPT = os.path.join(DIR_PATH, "server.py")
CLIENT_SCRIPT = os.path.join(DIR_PATH, "client.py")

class ChatMasterLauncher:
    def __init__(self, root):
        self.root = root
        self.root.title("NexusChat - Task 5 Master Control Hub")
        self.root.geometry("620x460")
        self.root.configure(bg="#0f172a")

        self.server_proc = None

        self._build_ui()
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    def _build_ui(self):
        # Header
        header = tk.Frame(self.root, bg="#1e293b", height=70)
        header.pack(fill=tk.X, side=tk.TOP)
        header.pack_propagate(False)

        h_frame = tk.Frame(header, bg="#1e293b")
        h_frame.pack(side=tk.LEFT, padx=20, pady=12)

        tk.Label(h_frame, text="💬 TASK 5: CHAT APPLICATION SUITE", font=("Segoe UI", 15, "bold"), fg="#38bdf8", bg="#1e293b").pack(anchor="w")
        tk.Label(h_frame, text="Oasis Infobyte Internship • Socket, Threading & SQLite Architecture", font=("Segoe UI", 9), fg="#94a3b8", bg="#1e293b").pack(anchor="w")

        body = tk.Frame(self.root, bg="#0f172a")
        body.pack(fill=tk.BOTH, expand=True, padx=25, pady=20)

        # Status Card
        self.status_card = tk.Frame(body, bg="#1e293b", bd=1, relief=tk.SOLID, padx=15, pady=12)
        self.status_card.pack(fill=tk.X, pady=(0, 15))

        self.lbl_server_status = tk.Label(
            self.status_card, text="● SERVER: OFFLINE (Click 'Start Server' below)",
            font=("Segoe UI", 10, "bold"), fg="#ef4444", bg="#1e293b"
        )
        self.lbl_server_status.pack(anchor="w")

        # Action Buttons Grid
        btn_grid = tk.Frame(body, bg="#0f172a")
        btn_grid.pack(fill=tk.BOTH, expand=True)

        btn_srv = tk.Button(
            btn_grid, text="🚀 1. Start Local Chat Server (Port 65432)", font=("Segoe UI", 11, "bold"),
            bg="#2563eb", fg="white", activebackground="#1d4ed8", activeforeground="white",
            relief=tk.FLAT, cursor="hand2", pady=10, command=self.start_server
        )
        btn_srv.pack(fill=tk.X, pady=6)

        btn_cli = tk.Button(
            btn_grid, text="💬 2. Launch Chat Client Window", font=("Segoe UI", 11, "bold"),
            bg="#059669", fg="white", activebackground="#047857", activeforeground="white",
            relief=tk.FLAT, cursor="hand2", pady=10, command=self.launch_client
        )
        btn_cli.pack(fill=tk.X, pady=6)

        btn_two = tk.Button(
            btn_grid, text="👥 3. Launch 2 Clients (Simulate Two-Way Real-Time Chat)", font=("Segoe UI", 11, "bold"),
            bg="#7c3aed", fg="white", activebackground="#6d28d9", activeforeground="white",
            relief=tk.FLAT, cursor="hand2", pady=10, command=self.launch_two_clients
        )
        btn_two.pack(fill=tk.X, pady=6)

        # Info Box
        lbl_info = tk.Label(
            body,
            text="💡 Tip: Click 'Launch 2 Clients' to immediately test real-time messaging between two separate users (e.g. Alice and Bob) across different chat rooms with emojis and SQLite history!",
            font=("Segoe UI", 9), fg="#94a3b8", bg="#0f172a", wraplength=560, justify=tk.LEFT
        )
        lbl_info.pack(fill=tk.X, pady=(10, 0))

    def start_server(self):
        if self.server_proc and self.server_proc.poll() is None:
            messagebox.showinfo("Server Running", "Chat server is already active on port 65432!")
            return

        try:
            self.server_proc = subprocess.Popen([sys.executable, SERVER_SCRIPT])
            time.sleep(0.5)
            self.lbl_server_status.config(text="● SERVER: ONLINE & LISTENING ON PORT 65432", fg="#10b981")
            messagebox.showinfo("Server Started", "Chat server successfully initialized and listening on localhost:65432!")
        except Exception as e:
            messagebox.showerror("Server Launch Error", f"Failed to start server: {e}")

    def launch_client(self):
        # Auto-start server if not already running
        if not self.server_proc or self.server_proc.poll() is not None:
            self.start_server()
            time.sleep(0.4)

        try:
            subprocess.Popen([sys.executable, CLIENT_SCRIPT])
        except Exception as e:
            messagebox.showerror("Client Launch Error", f"Failed to launch client: {e}")

    def launch_two_clients(self):
        # Ensure server is running
        if not self.server_proc or self.server_proc.poll() is not None:
            self.start_server()
            time.sleep(0.5)

        try:
            subprocess.Popen([sys.executable, CLIENT_SCRIPT])
            time.sleep(0.3)
            subprocess.Popen([sys.executable, CLIENT_SCRIPT])
            messagebox.showinfo(
                "Two Clients Launched",
                "Launched 2 client windows!\n\n1. Window 1: Register/Login as 'Alice'\n2. Window 2: Register/Login as 'Bob'\n\nSend messages between both windows to demonstrate real-time bidirectional socket communication!"
            )
        except Exception as e:
            messagebox.showerror("Error", f"Could not launch clients: {e}")

    def on_close(self):
        if self.server_proc and self.server_proc.poll() is None:
            try:
                self.server_proc.terminate()
            except Exception:
                pass
        self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = ChatMasterLauncher(root)
    root.mainloop()
