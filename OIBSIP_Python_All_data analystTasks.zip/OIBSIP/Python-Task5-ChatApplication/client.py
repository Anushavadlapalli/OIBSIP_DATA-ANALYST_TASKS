"""
Oasis Infobyte Internship - Task 5: Real-Time Chat Client (Advanced Tier)
Author: OIBSIP Intern
Tech Stack: Python, Tkinter, socket, threading, json
Features:
- Modern GUI dark theme with chat bubble styling
- Authentication window (Sign In & Sign Up)
- Multi-room selector (#general, #tech, #oasis-interns, + custom room)
- Emoji shortcode auto-replacement (:smile:, :heart:, :fire:, :rocket:, :thumbsup:)
- Interactive visual emoji toolbar
- In-app message history display with timestamp prefixes [HH:MM]
- Live online users sidebar
"""

import socket
import threading
import json
import os
import sys
import datetime
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext

HOST = "127.0.0.1"
PORT = 65432

EMOJI_MAP = {
    ":smile:": "😄",
    ":happy:": "😊",
    ":laugh:": "😂",
    ":cool:": "😎",
    ":heart:": "❤️",
    ":fire:": "🔥",
    ":rocket:": "🚀",
    ":thumbsup:": "👍",
    ":clap:": "👏",
    ":star:": "⭐",
    ":check:": "✅",
    ":party:": "🎉"
}

def parse_emojis(text):
    for code, symbol in EMOJI_MAP.items():
        text = text.replace(code, symbol)
    return text


class ChatClientApp:
    def __init__(self, root, host=HOST, port=PORT):
        self.root = root
        self.host = host
        self.port = port
        self.sock = None
        self.running = False
        self.username = None
        self.current_room = "#general"

        self.root.title("NexusChat - Real-Time Socket Messaging")
        self.root.geometry("860x640")
        self.root.minsize(760, 540)
        self.root.configure(bg="#0f172a")

        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

        # Show Auth Screen first
        self._show_auth_screen()

    # --- Connection & Socket Worker ---
    def connect_to_server(self):
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.sock.connect((self.host, self.port))
            self.running = True
            threading.Thread(target=self._receive_worker, daemon=True).start()
            return True
        except Exception as e:
            messagebox.showerror("Connection Error", f"Could not connect to Chat Server at {self.host}:{self.port}.\nPlease ensure server.py is running!\n\nError: {e}")
            return False

    def send_packet(self, data_dict):
        if self.sock and self.running:
            try:
                raw = json.dumps(data_dict) + "\n"
                self.sock.sendall(raw.encode("utf-8"))
            except Exception as e:
                print(f"Send error: {e}")

    def _receive_worker(self):
        buffer = ""
        while self.running:
            try:
                data = self.sock.recv(4096).decode("utf-8")
                if not data:
                    break
                buffer += data
                while "\n" in buffer:
                    line, buffer = buffer.split("\n", 1)
                    if not line.strip():
                        continue
                    try:
                        pkg = json.loads(line)
                        self.root.after(0, self._handle_incoming_packet, pkg)
                    except Exception:
                        continue
            except Exception:
                break

        if self.running:
            self.root.after(0, self._on_disconnected)

    def _on_disconnected(self):
        self.running = False
        messagebox.showwarning("Disconnected", "Connection to the chat server was lost.")

    # --- Packet Handlers ---
    def _handle_incoming_packet(self, pkg):
        ptype = pkg.get("type")

        if ptype == "auth_response":
            success = pkg.get("success")
            msg = pkg.get("message")
            action = pkg.get("action")

            if success:
                if action == "register":
                    messagebox.showinfo("Success", "Account created successfully! You can now log in.")
                else:
                    self.username = pkg.get("username")
                    self.current_room = pkg.get("room", "#general")
                    self._show_main_chat_ui()
            else:
                messagebox.showerror("Authentication Failed", msg)

        elif ptype == "message":
            u = pkg.get("username")
            txt = pkg.get("content")
            t = pkg.get("timestamp")
            is_self = (u == self.username)
            self._append_message(u, txt, t, is_self=is_self)

        elif ptype == "system":
            txt = pkg.get("content")
            t = pkg.get("timestamp")
            self._append_system(txt, t)

        elif ptype == "history":
            msgs = pkg.get("messages", [])
            self.chat_display.config(state=tk.NORMAL)
            self.chat_display.delete(1.0, tk.END)
            self.chat_display.config(state=tk.DISABLED)
            for u, c, t in msgs:
                self._append_message(u, c, t, is_self=(u == self.username))

        elif ptype == "room_joined":
            self.current_room = pkg.get("room")
            self.lbl_active_room.config(text=f"Room: {self.current_room}")
            msgs = pkg.get("messages", [])
            self.chat_display.config(state=tk.NORMAL)
            self.chat_display.delete(1.0, tk.END)
            self.chat_display.config(state=tk.DISABLED)
            for u, c, t in msgs:
                self._append_message(u, c, t, is_self=(u == self.username))

        elif ptype == "online_list":
            users = pkg.get("users", [])
            self._update_online_users(users)

    # --- Auth View ---
    def _show_auth_screen(self):
        for w in self.root.winfo_children():
            w.destroy()

        center_card = tk.Frame(self.root, bg="#1e293b", bd=1, relief=tk.SOLID, width=420, height=480)
        center_card.place(relx=0.5, rely=0.5, anchor=tk.CENTER)
        center_card.pack_propagate(False)

        tk.Label(center_card, text="💬 NEXUS CHAT", font=("Segoe UI", 18, "bold"), fg="#38bdf8", bg="#1e293b").pack(pady=(30, 5))
        tk.Label(center_card, text="Oasis Infobyte Internship • Task 5 Advanced Tier", font=("Segoe UI", 9), fg="#94a3b8", bg="#1e293b").pack(pady=(0, 25))

        f_inputs = tk.Frame(center_card, bg="#1e293b")
        f_inputs.pack(fill=tk.X, padx=35)

        tk.Label(f_inputs, text="Username:", font=("Segoe UI", 9, "bold"), fg="#cbd5e1", bg="#1e293b").pack(anchor="w", pady=(5, 2))
        self.auth_user_entry = tk.Entry(f_inputs, font=("Segoe UI", 11), bg="#0b1329", fg="white", relief=tk.FLAT, bd=6)
        self.auth_user_entry.pack(fill=tk.X, pady=(0, 10))

        tk.Label(f_inputs, text="Password:", font=("Segoe UI", 9, "bold"), fg="#cbd5e1", bg="#1e293b").pack(anchor="w", pady=(5, 2))
        self.auth_pass_entry = tk.Entry(f_inputs, show="•", font=("Segoe UI", 11), bg="#0b1329", fg="white", relief=tk.FLAT, bd=6)
        self.auth_pass_entry.pack(fill=tk.X, pady=(0, 20))
        self.auth_pass_entry.bind("<Return>", lambda e: self._attempt_login())

        btn_box = tk.Frame(center_card, bg="#1e293b")
        btn_box.pack(fill=tk.X, padx=35)

        btn_login = tk.Button(
            btn_box, text="🔐 Log In", font=("Segoe UI", 10, "bold"),
            bg="#2563eb", fg="white", activebackground="#1d4ed8", activeforeground="white",
            relief=tk.FLAT, cursor="hand2", pady=7, command=self._attempt_login
        )
        btn_login.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 6))

        btn_reg = tk.Button(
            btn_box, text="📝 Register", font=("Segoe UI", 10, "bold"),
            bg="#059669", fg="white", activebackground="#047857", activeforeground="white",
            relief=tk.FLAT, cursor="hand2", pady=7, command=self._attempt_register
        )
        btn_reg.pack(side=tk.RIGHT, fill=tk.X, expand=True, padx=(6, 0))

        tk.Label(center_card, text="Database Security: Passwords stored as SHA-256 hashes.", font=("Segoe UI", 8, "italic"), fg="#64748b", bg="#1e293b").pack(side=tk.BOTTOM, pady=15)

    def _attempt_login(self):
        u = self.auth_user_entry.get().strip()
        p = self.auth_pass_entry.get().strip()
        if not u or not p:
            messagebox.showwarning("Required", "Please provide both username and password.")
            return

        if not self.running:
            if not self.connect_to_server():
                return
        self.send_packet({"action": "login", "username": u, "password": p})

    def _attempt_register(self):
        u = self.auth_user_entry.get().strip()
        p = self.auth_pass_entry.get().strip()
        if not u or not p:
            messagebox.showwarning("Required", "Please provide both username and password.")
            return
        if len(p) < 4:
            messagebox.showwarning("Password Security", "Password must be at least 4 characters long.")
            return

        if not self.running:
            if not self.connect_to_server():
                return
        self.send_packet({"action": "register", "username": u, "password": p})

    # --- Main Chat UI ---
    def _show_main_chat_ui(self):
        for w in self.root.winfo_children():
            w.destroy()

        # Header Bar
        header = tk.Frame(self.root, bg="#1e293b", height=65)
        header.pack(fill=tk.X, side=tk.TOP)
        header.pack_propagate(False)

        h_left = tk.Frame(header, bg="#1e293b")
        h_left.pack(side=tk.LEFT, padx=18, pady=10)

        tk.Label(h_left, text="💬 NEXUS CHAT ROOMS", font=("Segoe UI", 14, "bold"), fg="#38bdf8", bg="#1e293b").pack(anchor="w")
        self.lbl_active_room = tk.Label(h_left, text=f"Room: {self.current_room}", font=("Segoe UI", 9, "bold"), fg="#10b981", bg="#1e293b")
        self.lbl_active_room.pack(anchor="w")

        h_right = tk.Frame(header, bg="#1e293b")
        h_right.pack(side=tk.RIGHT, padx=18, pady=12)

        tk.Label(h_right, text=f"👤 {self.username}", font=("Segoe UI", 10, "bold"), fg="#f8fafc", bg="#1e293b").pack(side=tk.LEFT, padx=(0, 10))

        btn_logout = tk.Button(
            h_right, text="Logout", font=("Segoe UI", 8, "bold"), bg="#dc2626", fg="white",
            relief=tk.FLAT, cursor="hand2", command=self._logout
        )
        btn_logout.pack(side=tk.LEFT)

        # Body Layout: Left Sidebar (Rooms & Users), Right: Chat Display & Input
        body = tk.Frame(self.root, bg="#0f172a")
        body.pack(fill=tk.BOTH, expand=True, padx=15, pady=12)

        # Left Sidebar
        sidebar = tk.Frame(body, bg="#1e293b", width=220, bd=1, relief=tk.SOLID)
        sidebar.pack(side=tk.LEFT, fill=tk.BOTH, padx=(0, 10))
        sidebar.pack_propagate(False)

        # Rooms List
        tk.Label(sidebar, text="Active Rooms", font=("Segoe UI", 10, "bold"), fg="#e2e8f0", bg="#1e293b").pack(anchor="w", padx=12, pady=(12, 6))

        rooms_box = tk.Frame(sidebar, bg="#1e293b")
        rooms_box.pack(fill=tk.X, padx=10)

        default_rooms = ["#general", "#tech-talk", "#oasis-interns", "#random"]
        for r_name in default_rooms:
            btn_r = tk.Button(
                rooms_box, text=r_name, font=("Segoe UI", 9), bg="#334155", fg="#f1f5f9",
                activebackground="#2563eb", activeforeground="white", relief=tk.FLAT,
                cursor="hand2", anchor="w", padx=8, pady=3,
                command=lambda rm=r_name: self.switch_room(rm)
            )
            btn_r.pack(fill=tk.X, pady=2)

        # Custom Room Join
        join_box = tk.Frame(sidebar, bg="#1e293b")
        join_box.pack(fill=tk.X, padx=10, pady=(8, 12))

        self.custom_room_entry = tk.Entry(join_box, font=("Segoe UI", 9), bg="#0b1329", fg="white", relief=tk.FLAT, bd=4)
        self.custom_room_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 4))
        self.custom_room_entry.insert(0, "#project")

        btn_join = tk.Button(
            join_box, text="Join", font=("Segoe UI", 8, "bold"), bg="#0284c7", fg="white",
            relief=tk.FLAT, cursor="hand2", command=self._join_custom_room
        )
        btn_join.pack(side=tk.RIGHT)

        # Online Users Panel
        tk.Label(sidebar, text="Online in Room", font=("Segoe UI", 10, "bold"), fg="#e2e8f0", bg="#1e293b").pack(anchor="w", padx=12, pady=(10, 4))

        self.user_listbox = tk.Listbox(
            sidebar, font=("Segoe UI", 9), bg="#0b1329", fg="#38bdf8",
            selectbackground="#2563eb", bd=0, highlightthickness=0
        )
        self.user_listbox.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))

        # Right Main Chat Area
        chat_pane = tk.Frame(body, bg="#1e293b", bd=1, relief=tk.SOLID)
        chat_pane.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        self.chat_display = scrolledtext.ScrolledText(
            chat_pane, wrap=tk.WORD, font=("Segoe UI", 10),
            bg="#0b1329", fg="#f8fafc", bd=0, padx=12, pady=10
        )
        self.chat_display.pack(fill=tk.BOTH, expand=True, padx=12, pady=(12, 5))
        self.chat_display.tag_config("self_hdr", foreground="#38bdf8", font=("Segoe UI", 9, "bold"))
        self.chat_display.tag_config("other_hdr", foreground="#a78bfa", font=("Segoe UI", 9, "bold"))
        self.chat_display.tag_config("sys_hdr", foreground="#10b981", font=("Segoe UI", 9, "italic"))
        self.chat_display.tag_config("msg_body", foreground="#f1f5f9", font=("Segoe UI", 10))
        self.chat_display.config(state=tk.DISABLED)

        # Emoji Shortcut Toolbar
        emoji_bar = tk.Frame(chat_pane, bg="#1e293b")
        emoji_bar.pack(fill=tk.X, padx=12, pady=2)

        tk.Label(emoji_bar, text="Quick Emojis:", font=("Segoe UI", 8, "bold"), fg="#94a3b8", bg="#1e293b").pack(side=tk.LEFT, padx=(0, 4))

        quick_emojis = ["😄", "❤️", "🔥", "🚀", "👍", "👏", "⭐", "🎉"]
        for em in quick_emojis:
            b = tk.Button(
                emoji_bar, text=em, font=("Segoe UI Emoji", 9), bg="#1e293b", fg="white",
                activebackground="#334155", bd=0, cursor="hand2", padx=3,
                command=lambda e=em: self._insert_emoji(e)
            )
            b.pack(side=tk.LEFT, padx=1)

        # Input & Send Row
        input_row = tk.Frame(chat_pane, bg="#1e293b")
        input_row.pack(fill=tk.X, padx=12, pady=(2, 12))

        self.msg_entry = tk.Entry(
            input_row, font=("Segoe UI", 10), bg="#0b1329", fg="white",
            insertbackground="#38bdf8", relief=tk.FLAT, bd=7
        )
        self.msg_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 8))
        self.msg_entry.bind("<Return>", lambda e: self.send_message())

        btn_send = tk.Button(
            input_row, text="Send 🚀", font=("Segoe UI", 9, "bold"),
            bg="#2563eb", fg="white", activebackground="#1d4ed8", activeforeground="white",
            relief=tk.FLAT, padx=16, cursor="hand2", command=self.send_message
        )
        btn_send.pack(side=tk.RIGHT)

    def _insert_emoji(self, emoji_char):
        self.msg_entry.insert(tk.END, emoji_char)
        self.msg_entry.focus_set()

    def _join_custom_room(self):
        r = self.custom_room_entry.get().strip()
        if not r:
            return
        if not r.startswith("#"):
            r = "#" + r
        self.switch_room(r)

    def switch_room(self, new_room):
        if new_room == self.current_room:
            return
        self.send_packet({"action": "join_room", "room": new_room})

    def send_message(self):
        raw = self.msg_entry.get().strip()
        if not raw:
            return
        # Replace emoji shortcodes
        content = parse_emojis(raw)
        self.msg_entry.delete(0, tk.END)
        self.send_packet({"action": "message", "content": content})

    def _append_message(self, username, content, timestamp, is_self=False):
        self.chat_display.config(state=tk.NORMAL)
        tag = "self_hdr" if is_self else "other_hdr"
        prefix = f"[{timestamp}] {username}: "
        self.chat_display.insert(tk.END, prefix, tag)
        self.chat_display.insert(tk.END, f"{content}\n", "msg_body")
        self.chat_display.see(tk.END)
        self.chat_display.config(state=tk.DISABLED)

    def _append_system(self, content, timestamp):
        self.chat_display.config(state=tk.NORMAL)
        self.chat_display.insert(tk.END, f"[{timestamp}] System: {content}\n", "sys_hdr")
        self.chat_display.see(tk.END)
        self.chat_display.config(state=tk.DISABLED)

    def _update_online_users(self, users):
        self.user_listbox.delete(0, tk.END)
        for u in users:
            self.user_listbox.insert(tk.END, f"● {u}")

    def _logout(self):
        self.running = False
        if self.sock:
            try:
                self.sock.close()
            except Exception:
                pass
        self._show_auth_screen()

    def on_close(self):
        self.running = False
        if self.sock:
            try:
                self.sock.close()
            except Exception:
                pass
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    app = ChatClientApp(root)
    root.mainloop()
