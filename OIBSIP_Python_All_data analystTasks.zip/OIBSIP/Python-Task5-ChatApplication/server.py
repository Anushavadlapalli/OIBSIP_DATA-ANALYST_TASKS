"""
Oasis Infobyte Internship - Task 5: Real-Time Chat Server (Advanced Tier)
Author: OIBSIP Intern
Tech Stack: Python, socket, threading, sqlite3, hashlib
Features:
- Multi-client TCP socket server running on localhost
- Multi-threading for concurrent client connections
- User authentication & registration (passwords hashed using SHA-256 in SQLite)
- Multi-room routing (#general, #tech, #internship)
- Message history persistence in SQLite database
- Broadcasts join, message, room switch, and leave notifications
"""

import socket
import threading
import sqlite3
import hashlib
import json
import datetime
import os
import sys

HOST = "127.0.0.1"
PORT = 65432
DB_FILE = os.path.join(os.path.dirname(__file__), "chat_database.db")

# Thread-safe database lock
db_lock = threading.Lock()

def init_db():
    with db_lock:
        conn = sqlite3.connect(DB_FILE)
        cur = conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                room TEXT NOT NULL,
                username TEXT NOT NULL,
                content TEXT NOT NULL,
                timestamp TEXT NOT NULL
            )
        """)
        conn.commit()
        conn.close()

def hash_password(password):
    return hashlib.sha256(password.encode("utf-8")).hexdigest()

def register_user(username, password):
    with db_lock:
        try:
            conn = sqlite3.connect(DB_FILE)
            cur = conn.cursor()
            cur.execute("INSERT INTO users (username, password_hash) VALUES (?, ?)", (username, hash_password(password)))
            conn.commit()
            conn.close()
            return True, "Registration successful."
        except sqlite3.IntegrityError:
            return False, "Username already exists."
        except Exception as e:
            return False, str(e)

def verify_user(username, password):
    with db_lock:
        try:
            conn = sqlite3.connect(DB_FILE)
            cur = conn.cursor()
            cur.execute("SELECT password_hash FROM users WHERE username = ?", (username,))
            row = cur.fetchone()
            conn.close()
            if row and row[0] == hash_password(password):
                return True, "Login successful."
            return False, "Invalid username or password."
        except Exception as e:
            return False, str(e)

def save_message(room, username, content, timestamp):
    with db_lock:
        try:
            conn = sqlite3.connect(DB_FILE)
            cur = conn.cursor()
            cur.execute("INSERT INTO messages (room, username, content, timestamp) VALUES (?, ?, ?, ?)", (room, username, content, timestamp))
            conn.commit()
            conn.close()
        except Exception as e:
            print(f"Failed to save message: {e}")

def get_history(room, limit=30):
    with db_lock:
        try:
            conn = sqlite3.connect(DB_FILE)
            cur = conn.cursor()
            cur.execute("SELECT username, content, timestamp FROM messages WHERE room = ? ORDER BY id DESC LIMIT ?", (room, limit))
            rows = cur.fetchall()
            conn.close()
            return list(reversed(rows))
        except Exception as e:
            print(f"Failed to load history: {e}")
            return []


class ChatServer:
    def __init__(self, host=HOST, port=PORT):
        self.host = host
        self.port = port
        self.server_socket = None
        self.clients = {}  # socket -> {"username": str, "room": str}
        self.lock = threading.Lock()
        self.running = False
        init_db()

    def start(self):
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server_socket.bind((self.host, self.port))
        self.server_socket.listen(10)
        self.running = True
        print(f"[*] Chat Server listening on {self.host}:{self.port}")

        while self.running:
            try:
                client_sock, addr = self.server_socket.accept()
                threading.Thread(target=self.handle_client, args=(client_sock, addr), daemon=True).start()
            except Exception as e:
                if self.running:
                    print(f"Accept error: {e}")
                break

    def stop(self):
        self.running = False
        if self.server_socket:
            try:
                self.server_socket.close()
            except Exception:
                pass

    def send_packet(self, client_sock, packet_dict):
        try:
            msg_str = json.dumps(packet_dict) + "\n"
            client_sock.sendall(msg_str.encode("utf-8"))
        except Exception:
            pass

    def broadcast_to_room(self, room, packet_dict, exclude_sock=None):
        with self.lock:
            for sock, info in list(self.clients.items()):
                if sock != exclude_sock and info.get("room") == room:
                    self.send_packet(sock, packet_dict)

    def handle_client(self, client_sock, addr):
        buffer = ""
        authenticated_user = None
        current_room = "#general"

        try:
            while self.running:
                data = client_sock.recv(4096).decode("utf-8")
                if not data:
                    break
                buffer += data
                while "\n" in buffer:
                    line, buffer = buffer.split("\n", 1)
                    if not line.strip():
                        continue
                    try:
                        pkg = json.loads(line)
                    except Exception:
                        continue

                    action = pkg.get("action")

                    # Handle Registration
                    if action == "register":
                        u = pkg.get("username", "").strip()
                        p = pkg.get("password", "").strip()
                        ok, msg = register_user(u, p)
                        self.send_packet(client_sock, {"type": "auth_response", "success": ok, "message": msg, "action": "register"})

                    # Handle Login
                    elif action == "login":
                        u = pkg.get("username", "").strip()
                        p = pkg.get("password", "").strip()
                        ok, msg = verify_user(u, p)
                        if ok:
                            authenticated_user = u
                            with self.lock:
                                self.clients[client_sock] = {"username": u, "room": current_room}
                            self.send_packet(client_sock, {"type": "auth_response", "success": True, "message": msg, "username": u, "room": current_room})
                            
                            # Send history for initial room
                            hist = get_history(current_room)
                            self.send_packet(client_sock, {"type": "history", "room": current_room, "messages": hist})

                            # Notify others
                            now_str = datetime.datetime.now().strftime("%H:%M")
                            notice = {"type": "system", "room": current_room, "content": f"⚡ {u} joined {current_room}", "timestamp": now_str}
                            self.broadcast_to_room(current_room, notice, exclude_sock=client_sock)
                            self._broadcast_online_users(current_room)
                        else:
                            self.send_packet(client_sock, {"type": "auth_response", "success": False, "message": msg})

                    # Handle Room Change
                    elif action == "join_room" and authenticated_user:
                        new_room = pkg.get("room", "#general")
                        old_room = current_room
                        with self.lock:
                            if client_sock in self.clients:
                                self.clients[client_sock]["room"] = new_room
                        current_room = new_room

                        now_str = datetime.datetime.now().strftime("%H:%M")
                        # Notify old room
                        self.broadcast_to_room(old_room, {"type": "system", "room": old_room, "content": f"{authenticated_user} left to join {new_room}", "timestamp": now_str})
                        self._broadcast_online_users(old_room)

                        # Confirm new room & send history
                        hist = get_history(new_room)
                        self.send_packet(client_sock, {"type": "room_joined", "room": new_room, "messages": hist})

                        # Notify new room
                        self.broadcast_to_room(new_room, {"type": "system", "room": new_room, "content": f"⚡ {authenticated_user} joined {new_room}", "timestamp": now_str}, exclude_sock=client_sock)
                        self._broadcast_online_users(new_room)

                    # Handle Message Broadcast
                    elif action == "message" and authenticated_user:
                        raw_content = pkg.get("content", "").strip()
                        if raw_content:
                            now_str = datetime.datetime.now().strftime("%H:%M")
                            # Save to SQLite
                            save_message(current_room, authenticated_user, raw_content, now_str)

                            msg_packet = {
                                "type": "message",
                                "room": current_room,
                                "username": authenticated_user,
                                "content": raw_content,
                                "timestamp": now_str
                            }
                            # Send to all in the room (including sender)
                            with self.lock:
                                for s, inf in self.clients.items():
                                    if inf.get("room") == current_room:
                                        self.send_packet(s, msg_packet)

        except Exception as e:
            print(f"Client exception: {e}")
        finally:
            with self.lock:
                if client_sock in self.clients:
                    u = self.clients[client_sock].get("username")
                    rm = self.clients[client_sock].get("room")
                    del self.clients[client_sock]
                    if u and rm:
                        now_str = datetime.datetime.now().strftime("%H:%M")
                        self.broadcast_to_room(rm, {"type": "system", "room": rm, "content": f"👋 {u} disconnected.", "timestamp": now_str})
                        self._broadcast_online_users(rm)
            try:
                client_sock.close()
            except Exception:
                pass

    def _broadcast_online_users(self, room):
        users = []
        with self.lock:
            for s, inf in self.clients.items():
                if inf.get("room") == room:
                    users.append(inf.get("username"))
        packet = {"type": "online_list", "room": room, "users": users}
        with self.lock:
            for s, inf in self.clients.items():
                if inf.get("room") == room:
                    self.send_packet(s, packet)

if __name__ == "__main__":
    server = ChatServer()
    try:
        server.start()
    except KeyboardInterrupt:
        server.stop()
        print("Server shutdown.")
