# OIBSIP — Python Programming Task 5: Real-Time Multi-Room Chat Application (Advanced Tier)

![Python](https://img.shields.io/badge/Python-3.8%2B-blue.svg)
![Sockets](https://img.shields.io/badge/Network-TCP%20Sockets-red.svg)
![GUI](https://img.shields.io/badge/GUI-Tkinter-green.svg)
![Database](https://img.shields.io/badge/Storage-SQLite3-lightgrey.svg)
![Status](https://img.shields.io/badge/Status-Completed-success.svg)

---

## 📌 Project Overview
**NexusChat** is a production-style, real-time multi-threaded chat application built in Python using TCP sockets, asynchronous multi-threading, SQLite data persistence, and a modern Tkinter graphical user interface.

Developed for the Oasis Infobyte Internship (Python Programming Track), this application supports concurrent users, multi-room channels (`#general`, `#tech-talk`, `#oasis-interns`, plus custom room creation), user registration with SHA-256 password hashing, persistent room message history, live online user sidebars, emoji shortcode parsing (`:smile:`, `:fire:`, `:rocket:`), and graceful disconnection handling.

---

## 🔐 Security & Architecture Transparency (End-to-End Awareness)

As required by the Oasis Infobyte SIP guidelines:
1. **Password Storage**: Passwords are **never** stored in plain text. When a user registers, their password is salted and hashed using cryptographic **SHA-256** before being written to SQLite (`chat_database.db`).
2. **Message Storage**: Room messages (username, content, timestamp) are stored in the local SQLite relational database to support message history recovery when users join a channel.
3. **Transport Security Disclosure**: Communication between client and server uses standard plaintext TCP sockets over localhost/LAN. **In this academic implementation, message payloads in transit are not end-to-end encrypted (E2EE)** with TLS/SSL. For production internet deployment across public networks, wrapping the sockets with Python's `ssl.create_default_context()` and deploying TLS certificates is recommended to prevent network sniffing.

---

## ✨ Features Checklist

### Beginner Tier
- [x] **Server Script**: Dedicated `server.py` listening on TCP port 65432 using non-blocking socket patterns.
- [x] **Client Script**: Standalone `client.py` connecting to localhost.
- [x] **Bidirectional Real-Time Communication**: Messages instantly propagated between clients.
- [x] **Timestamp Prefixes**: Every message formatted with `[HH:MM] Username: Message`.
- [x] **Graceful Disconnection**: Automatically cleans up socket connections and broadcasts departure alerts.
- [x] **Localhost Deployment**: Both scripts run concurrently on the same machine.

### Advanced Tier
- [x] **Modern Graphical Interface**: Built using Tkinter with a sleek dark slate messaging interface.
- [x] **User Authentication**: Login and Registration system backed by SQLite and SHA-256 password hashing.
- [x] **Multi-Room Architecture**: Switch between rooms (`#general`, `#tech-talk`, `#oasis-interns`) or join custom user-created rooms.
- [x] **Historical Message Sync**: Previous room messages are automatically fetched from SQLite and loaded upon joining.
- [x] **Active Online Users Panel**: Live list of active users present in the current channel.
- [x] **Emoji Shortcode Engine**: Automatic parsing of `:smile:`, `:heart:`, `:fire:`, `:rocket:`, `:thumbsup:` + interactive emoji toolbar.
- [x] **1-Click Suite Runner**: `chat_app.py` launcher that starts the server and launches 2 client windows simultaneously for instant testing.

---

## 🚀 How to Run

### Option A: 1-Click Master Launcher (Recommended)
Run the launcher GUI to control everything from one place:
```bash
python chat_app.py
```
- Click **"🚀 1. Start Local Chat Server"**
- Click **"👥 3. Launch 2 Clients"** to instantly open two client windows side-by-side!

### Option B: Individual Standalone Execution
```bash
# Terminal 1: Start Server
python server.py

# Terminal 2: Start First Client (e.g. Alice)
python client.py

# Terminal 3: Start Second Client (e.g. Bob)
python client.py
```

---

## 📹 Screen Recording Walkthrough Script (for Task Submission)

> **⚠️ OASIS INFOBYTE REQUIREMENT**: The video must begin with a clear 2-second static title card displaying:
> 1. Full Name
> 2. Assigned Track: **Python Programming**
> 3. Task Title: **Task 5 - Chat Application**

### Video Step-by-Step Flow:
1. **[0:00 - 0:02]** Static title card showing Name, Track, and Task Title.
2. **[0:03 - 0:15]** Launch `chat_app.py`. Click **Start Local Chat Server**, then click **Launch 2 Clients**.
3. **[0:16 - 0:35]** In Window 1: Register as `Alice`. In Window 2: Register as `Bob`. Show that both windows enter the `#general` room.
4. **[0:36 - 0:55]** Alice types: `Hello Bob! Welcome to Oasis Infobyte! :rocket: :fire:`. Show the real-time arrival on Bob's screen with timestamp and emoji rendering.
5. **[0:56 - 1:10]** Bob replies using the emoji toolbar. Alice and Bob both see the message in real-time.
6. **[1:11 - 1:20]** Switch Bob to the `#tech-talk` room. Show the room transition and separate message context.
7. **[1:21 - 1:30]** Close one client window to demonstrate the graceful disconnection notification in the room.

---

## 💼 LinkedIn Submission Post Template

```text
Thrilled to share that I have completed Task 5: "Real-Time Multi-Room Socket Chat Application" for my Python Programming Internship at Oasis Infobyte (OIBSIP)! 🚀

Project: NexusChat - Concurrent Multi-Threaded Messaging Engine
Tech Stack: Python, TCP Sockets, Multi-Threading, Tkinter, SQLite3, SHA-256 Hashing, JSON

Key Highlights:
✨ Multi-threaded asynchronous socket server handling concurrent clients
✨ User authentication & registration system with SHA-256 password encryption
✨ Dynamic multi-room channel routing (#general, #tech-talk, #oasis-interns, custom rooms)
✨ Room message history synchronization using persistent SQLite storage
✨ Real-time emoji parser (:fire:, :rocket:, :smile:) and interactive emoji toolbar
✨ Live online users sidebar and graceful disconnect broadcasting
✨ Architectural security disclosure documenting in-transit vs at-rest encryption

Check out the repository on GitHub:
🔗 https://github.com/YOUR_USERNAME/OIBSIP

Thank you @Oasis Infobyte for this fantastic hands-on learning experience!

#oasisinfobyte #internship #python #socketprogramming #networking #multithreading #tkinter #chattingapp
```
