# OIBSIP — Python Programming Task 4: Weather App & Live Forecasting Suite (Advanced Tier)

![Python](https://img.shields.io/badge/Python-3.8%2B-blue.svg)
![API](https://img.shields.io/badge/Weather%20API-Open--Meteo-brightgreen.svg)
![GUI](https://img.shields.io/badge/GUI-Tkinter-green.svg)
![Status](https://img.shields.io/badge/Status-Completed-success.svg)

---

## 📌 Project Overview
**Atmosphere Pro** is a comprehensive, real-time meteorological forecasting application developed for the Oasis Infobyte SIP Python Programming track.

Built using an advanced Tkinter graphical user interface, this project integrates live weather APIs (Open-Meteo & wttr.in) that require **zero API key setup** from the user, while supporting OpenWeatherMap API endpoints. It features instant City/ZIP lookup, automatic IP-based location detection, dynamic °C/°F unit toggling, an hourly 6-hour projection carousel, a 5-day daily forecast table, atmospheric conditions metrics (humidity, wind speed, pressure, UV index), and complete in-GUI error messaging.

---

## ✨ Features Checklist

### Beginner Tier
- [x] **City & ZIP Code Query**: Real-time location search field.
- [x] **Live API Call & JSON Parsing**: Robust REST HTTP request pipeline with structured JSON decoders.
- [x] **Essential Metric Reporting**: Displays temperature (°C & °F), humidity percentage, wind speed, and weather condition string.
- [x] **Graceful Error Handling**: Detects network timeouts, unknown cities, and invalid inputs gracefully.
- [x] **Input Validation**: Rejects empty queries with helpful warnings.

### Advanced Tier
- [x] **Modern Graphical Interface**: Modern dark slate dashboard UI with weather condition badges.
- [x] **Dynamic Weather Visuals**: Displays contextual weather condition icons (clear, cloudy, rainy, thunder, fog, etc.).
- [x] **6-Hour Hourly Forecast Panel**: Sequential cards showing upcoming hourly temperatures and conditions.
- [x] **5-Day Daily Forecast Panel**: Weekly outlook showing day-by-day high/low temperatures and status.
- [x] **Unit Switcher (°C / °F)**: Instant dynamic unit toggle without needing to re-fetch from the network.
- [x] **Auto IP Location Detection**: 1-click geolocation based on the user's external IP address.
- [x] **In-GUI Error Display**: Error messages appear directly on the application interface rather than terminal logs.
- [x] **Zero-Key Out-Of-The-Box Reliability**: Runs instantly anywhere without registering or configuring external API keys.

---

## 🚀 How to Run

### Prerequisites
Uses Python 3.8+ built-in `urllib` and `tkinter` (optional: `requests`).

### Execution
Run the standalone weather app:
```bash
python weather_app.py
```

---

## 📹 Screen Recording Walkthrough Script (for Task Submission)

> **⚠️ OASIS INFOBYTE REQUIREMENT**: The video must begin with a clear 2-second static title card displaying:
> 1. Full Name
> 2. Assigned Track: **Python Programming**
> 3. Task Title: **Task 4 - Basic Weather App**

### Video Step-by-Step Flow:
1. **[0:00 - 0:02]** Static title card showing Name, Track, and Task Title.
2. **[0:03 - 0:15]** Launch `weather_app.py`. Show the default loaded weather (e.g. Hyderabad) with the current temperature, conditions, and weather icon.
3. **[0:16 - 0:30]** Click the **°C / °F** toggle buttons at the top right. Watch all temperatures (hero, hourly, and 5-day) instantly recalculate without lag.
4. **[0:31 - 0:45]** Type another city (e.g., `London` or `Tokyo`) in the search bar and press Enter. Show the updated weather metrics (humidity, wind speed, pressure).
5. **[0:46 - 1:00]** Click **📍 Detect Location**. Demonstrate the IP-based automatic geolocation retrieval.
6. **[1:01 - 1:15]** Highlight the **6-Hour Hourly Forecast** cards and the **5-Day Daily Forecast** summary table.
7. **[1:16 - 1:30]** Conclude walkthrough demonstrating clean in-GUI error handling for a deliberately misspelled city.

---

## 💼 LinkedIn Submission Post Template

```text
Proud to share that I have completed Task 4: "Real-Time Weather App & Forecast Suite" as part of my Python Programming Internship at Oasis Infobyte (OIBSIP)! 🚀

Project: Atmosphere Pro - Live Meteorological Intelligence
Tech Stack: Python, Tkinter, Open-Meteo REST API, IP Geolocation, JSON, Threading

Key Highlights:
✨ Real-time global weather search by City Name or ZIP code
✨ Automatic IP-based location detection
✨ Live meteorological metrics: Temperature, Feels-like, Humidity, Wind speed, and Surface Pressure
✨ Seamless °C / °F unit toggle switch with instantaneous recalculation
✨ 6-hour hourly projection cards & 5-day daily forecast breakdown
✨ Modern responsive dark GUI with visual weather status indicators
✨ In-GUI error messaging & robust offline fallback architecture

Check out the source code on GitHub:
🔗 https://github.com/YOUR_USERNAME/OIBSIP

Thank you @Oasis Infobyte for this fantastic learning journey!

#oasisinfobyte #internship #python #api #restapi #weatherapp #tkinter #softwareengineering
```
