# OIBSIP — Python Programming Task 3: Cryptographic Password Generator (Advanced Tier)

![Python](https://img.shields.io/badge/Python-3.8%2B-blue.svg)
![Security](https://img.shields.io/badge/CSPRNG-secrets%20module-red.svg)
![GUI](https://img.shields.io/badge/GUI-Tkinter-green.svg)
![Status](https://img.shields.io/badge/Status-Completed-success.svg)

---

## 📌 Project Overview
**FortressPass** is a high-security, cryptographically secure password generator and passphrase generator developed for the Oasis Infobyte SIP Python Programming track.

While standard beginner generators often rely on the deterministic `random` module (which is predictable and unsuitable for security), **FortressPass** utilizes Python's OS-backed CSPRNG `secrets` module, guarantees character diversity, eliminates visually ambiguous characters, calculates Shannon entropy in bits, provides real-time strength assessment, and keeps a strictly non-persistent in-memory generation history.

---

## 🔐 Why `secrets` Instead of `random`?
The standard Python `random` module uses the **Mersenne Twister** pseudo-random number generator (PRNG). If an attacker observes approximately 624 generated outputs, the entire internal state of the generator can be reconstructed, making future passwords completely predictable.

In contrast, Python's `secrets` module accesses the underlying operating system's cryptographic entropy source (`CryptGenRandom` on Windows, `/dev/urandom` on POSIX systems), guaranteeing non-deterministic, cryptographically strong randomness suitable for production credential generation.

---

## ✨ Features Checklist

### Beginner Tier
- [x] **Configurable Length**: User controls password length (minimum 8 characters strictly enforced).
- [x] **Character Diversity Selection**: Checkboxes for Uppercase (A-Z), Lowercase (a-z), Numbers (0-9), and Symbols (!@#$).
- [x] **Multi-Type Validation**: Rejects requests unless at least 2 character types are chosen.
- [x] **Clean Form Validation**: Graceful rejection of invalid settings without crashes.
- [x] **Continuous Generation**: Infinite repeat generation without restarting.

### Advanced Tier
- [x] **Modern Graphical Interface**: Dark slate GUI built with responsive Tkinter controls and sliders.
- [x] **Cryptographic CSPRNG**: Built exclusively using `secrets.choice` and Fisher-Yates shuffle with `secrets.randbelow`.
- [x] **Strict Security Guarantees**: Guaranteed at least 1 character from every checked character category.
- [x] **Ambiguous Character Filter**: Excludes visually identical characters (`0`, `O`, `o`, `1`, `l`, `I`, `|`, etc.).
- [x] **Dynamic Strength & Entropy Meter**: Displays real-time rating (Weak, Medium, Strong, Maximum) and Shannon entropy in bits.
- [x] **Auto & Manual Clipboard Copy**: 1-click clipboard integration with animated toast alert.
- [x] **In-Memory Session History**: Displays the last 5 generated passwords during the session (cleared immediately upon exit for security).
- [x] **XKCD Passphrase Mode**: Bonus feature generating memorable multi-word dictionary passphrases with separators.

---

## 🚀 How to Run

### Prerequisites
Uses standard Python 3.8+ library modules (no third-party pip dependencies required!).

### Execution
Run the standalone generator:
```bash
python password_generator.py
```

---

## 📹 Screen Recording Walkthrough Script (for Task Submission)

> **⚠️ OASIS INFOBYTE REQUIREMENT**: The video must begin with a clear 2-second static title card displaying:
> 1. Full Name
> 2. Assigned Track: **Python Programming**
> 3. Task Title: **Task 3 - Random Password Generator**

### Video Step-by-Step Flow:
1. **[0:00 - 0:02]** Static title card showing Name, Track, and Task Title.
2. **[0:03 - 0:15]** Launch `password_generator.py`. Show the initial 16-character generated password and strength meter (`Strong / Maximum`).
3. **[0:16 - 0:30]** Adjust the slider from 8 to 28 characters. Check and uncheck character sets. Show the real-time entropy update in bits.
4. **[0:31 - 0:45]** Toggle **Exclude Ambiguous Characters (0, O, 1, l, I)**. Generate a new password and verify the absence of confusing symbols.
5. **[0:46 - 1:00]** Click **Passphrase Mode**. Show the readable XKCD-style memorable passphrase.
6. **[1:01 - 1:15]** Demonstrate the **In-Memory Session History (Last 5)** on the right panel, copy a previous password, and highlight the toast message.
7. **[1:16 - 1:30]** Conclude walkthrough highlighting CSPRNG verification and zero-persistence security.

---

## 💼 LinkedIn Submission Post Template

```text
Excited to announce the completion of Task 3: "Cryptographically Secure Password Generator" for the Python Programming Internship at Oasis Infobyte (OIBSIP)! 🚀

Project: FortressPass - Advanced CSPRNG Password Suite
Tech Stack: Python, Tkinter, secrets module, Cryptographic Entropy, OOP

Key Security & UI Highlights:
✨ Cryptographically secure random generation using Python's 'secrets' module (CSPRNG)
✨ Dynamic entropy calculation (in bits) & multi-tier password strength visualizer
✨ Configurable sliders (8-64 chars) with guaranteed character set distribution
✨ Ambiguous character filtering (removes confusing 0/O, 1/l/I characters)
✨ 1-click clipboard integration with animated toast alerts
✨ In-memory non-persistent session history (last 5 passwords)
✨ Bonus: XKCD-style memorable multi-word passphrase generator

Check out the full GitHub repository:
🔗 https://github.com/YOUR_USERNAME/OIBSIP

Huge thanks to @Oasis Infobyte for this engaging task!

#oasisinfobyte #internship #python #cybersecurity #cryptography #infosec #softwaredevelopment #tkinter
```
