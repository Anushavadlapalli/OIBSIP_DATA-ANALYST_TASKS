"""
Oasis Infobyte Internship - Task 3: Random Password Generator (Advanced Tier)
Author: OIBSIP Intern
Features:
- GUI built with modern Tkinter styling
- Cryptographically secure generation using the Python 'secrets' module
- Password length slider (8 to 64 characters)
- Multi-character toggle checkboxes: Uppercase, Lowercase, Numbers, Symbols
- Strict security rule enforcement: guaranteed at least 1 character from each chosen set
- Ambiguous character exclusion filter (removes 0, O, o, 1, l, I, etc.)
- Dynamic password strength meter & entropy calculator (Weak / Medium / Strong / Maximum)
- Instant 'Copy to Clipboard' with animated notification banner
- In-memory session history displaying the last 5 generated passwords (never saved to disk)
- Passphrase generation mode (XKCD-style memorable dictionary passwords)
"""

import sys
import os
import string
import secrets
import math
import tkinter as tk
from tkinter import ttk, messagebox

# Wordlist for passphrase generator
PASSPHRASE_WORDS = [
    "quantum", "cipher", "matrix", "falcon", "orbit", "galaxy", "stellar", "nebula",
    "shield", "vortex", "zenith", "crystal", "aurora", "beacon", "crypto", "dragon",
    "echo", "frost", "gravity", "horizon", "ignite", "javelin", "knight", "lunar",
    "meteor", "neutron", "ocean", "phoenix", "pulsar", "quasar", "radius", "shadow",
    "titan", "ultra", "vector", "wizard", "xenon", "yield", "zephyr", "solis"
]

class PasswordGeneratorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("FortressPass - Advanced Cryptographic Password Suite")
        self.root.geometry("860x660")
        self.root.minsize(780, 580)
        self.root.configure(bg="#0f172a")

        # Variables
        self.length_var = tk.IntVar(value=16)
        self.use_upper = tk.BooleanVar(value=True)
        self.use_lower = tk.BooleanVar(value=True)
        self.use_digits = tk.BooleanVar(value=True)
        self.use_symbols = tk.BooleanVar(value=True)
        self.exclude_ambiguous = tk.BooleanVar(value=False)
        self.auto_copy = tk.BooleanVar(value=True)

        self.last_passwords = []  # In-memory history (max 5)

        self._build_ui()
        self.generate_password()

    def _build_ui(self):
        # Header Bar
        header = tk.Frame(self.root, bg="#1e293b", height=70)
        header.pack(fill=tk.X, side=tk.TOP)
        header.pack_propagate(False)

        title_frame = tk.Frame(header, bg="#1e293b")
        title_frame.pack(side=tk.LEFT, padx=20, pady=12)

        lbl_title = tk.Label(
            title_frame, text="🛡️ FORTRESSPASS • CRYPTO KEYGEN",
            font=("Segoe UI", 16, "bold"), fg="#38bdf8", bg="#1e293b"
        )
        lbl_title.pack(anchor="w")

        lbl_sub = tk.Label(
            title_frame, text="Oasis Infobyte Internship Task 3 • Advanced Cryptographic Tier (secrets module)",
            font=("Segoe UI", 9), fg="#94a3b8", bg="#1e293b"
        )
        lbl_sub.pack(anchor="w")

        # Top Badge
        badge = tk.Label(
            header, text="CSPRNG VERIFIED", font=("Segoe UI", 9, "bold"),
            fg="#10b981", bg="#064e3b", padx=10, pady=4, relief=tk.FLAT
        )
        badge.pack(side=tk.RIGHT, padx=20, pady=20)

        # Main Layout
        body = tk.Frame(self.root, bg="#0f172a")
        body.pack(fill=tk.BOTH, expand=True, padx=20, pady=15)

        # Output Display Card (Hero area)
        output_card = tk.Frame(body, bg="#1e293b", bd=1, relief=tk.SOLID)
        output_card.pack(fill=tk.X, pady=(0, 15))

        # Output Field & Copy Button Container
        display_box = tk.Frame(output_card, bg="#0b1329", bd=1, relief=tk.SOLID)
        display_box.pack(fill=tk.X, padx=15, pady=15)

        self.pass_entry = tk.Entry(
            display_box, font=("Consolas", 15, "bold"), bg="#0b1329", fg="#38bdf8",
            relief=tk.FLAT, bd=10, justify=tk.LEFT
        )
        self.pass_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(10, 5))

        btn_copy = tk.Button(
            display_box, text="📋 Copy", font=("Segoe UI", 10, "bold"),
            bg="#2563eb", fg="white", activebackground="#1d4ed8", activeforeground="white",
            relief=tk.FLAT, padx=16, pady=8, cursor="hand2", command=self.copy_to_clipboard
        )
        btn_copy.pack(side=tk.RIGHT, padx=10)

        # Strength Bar & Info
        meter_row = tk.Frame(output_card, bg="#1e293b")
        meter_row.pack(fill=tk.X, padx=15, pady=(0, 12))

        self.strength_canvas = tk.Canvas(meter_row, height=8, bg="#334155", highlightthickness=0)
        self.strength_canvas.pack(fill=tk.X, side=tk.TOP, pady=(0, 6))

        info_bar = tk.Frame(meter_row, bg="#1e293b")
        info_bar.pack(fill=tk.X)

        self.lbl_strength = tk.Label(
            info_bar, text="Strength: Evaluating...",
            font=("Segoe UI", 9, "bold"), fg="#10b981", bg="#1e293b"
        )
        self.lbl_strength.pack(side=tk.LEFT)

        self.lbl_entropy = tk.Label(
            info_bar, text="Entropy: -- bits",
            font=("Segoe UI", 9), fg="#94a3b8", bg="#1e293b"
        )
        self.lbl_entropy.pack(side=tk.RIGHT)

        # Notification Toast Label
        self.lbl_toast = tk.Label(
            output_card, text="", font=("Segoe UI", 9, "bold"),
            fg="#10b981", bg="#1e293b"
        )
        self.lbl_toast.pack(pady=(0, 6))

        # Bottom Area: Left Controls & Right Session History
        bottom_box = tk.Frame(body, bg="#0f172a")
        bottom_box.pack(fill=tk.BOTH, expand=True)

        # Left Column: Configuration Settings
        cfg_frame = tk.LabelFrame(bottom_box, text=" Generator Parameters ", font=("Segoe UI", 10, "bold"), fg="#cbd5e1", bg="#1e293b", padx=15, pady=12)
        cfg_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))

        # Length Slider
        len_top = tk.Frame(cfg_frame, bg="#1e293b")
        len_top.pack(fill=tk.X, pady=(0, 4))

        tk.Label(len_top, text="Password Length (chars):", font=("Segoe UI", 9, "bold"), fg="#e2e8f0", bg="#1e293b").pack(side=tk.LEFT)
        self.lbl_len_display = tk.Label(len_top, text="16", font=("Segoe UI", 10, "bold"), fg="#38bdf8", bg="#1e293b")
        self.lbl_len_display.pack(side=tk.RIGHT)

        self.slider = ttk.Scale(
            cfg_frame, from_=8, to=64, orient=tk.HORIZONTAL,
            variable=self.length_var, command=self._on_slider_changed
        )
        self.slider.pack(fill=tk.X, pady=(0, 12))

        # Character Checkboxes
        chk_opts = [
            ("Include Uppercase Letters (A-Z)", self.use_upper),
            ("Include Lowercase Letters (a-z)", self.use_lower),
            ("Include Numeric Digits (0-9)", self.use_digits),
            ("Include Special Symbols (!@#$)", self.use_symbols),
            ("Exclude Ambiguous Characters (0, O, 1, l, I)", self.exclude_ambiguous),
            ("Auto-Copy to Clipboard on Generate", self.auto_copy)
        ]

        for text, var in chk_opts:
            cb = tk.Checkbutton(
                cfg_frame, text=text, variable=var, font=("Segoe UI", 9),
                fg="#f1f5f9", bg="#1e293b", selectcolor="#0b1329",
                activebackground="#1e293b", activeforeground="white"
            )
            cb.pack(anchor="w", pady=2)

        # Action Buttons
        btn_grid = tk.Frame(cfg_frame, bg="#1e293b")
        btn_grid.pack(fill=tk.X, pady=(15, 0))

        btn_generate = tk.Button(
            btn_grid, text="⚡ GENERATE PASSWORD", font=("Segoe UI", 10, "bold"),
            bg="#059669", fg="white", activebackground="#047857", activeforeground="white",
            relief=tk.FLAT, cursor="hand2", pady=8, command=self.generate_password
        )
        btn_generate.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))

        btn_passphrase = tk.Button(
            btn_grid, text="🔑 Passphrase Mode", font=("Segoe UI", 9, "bold"),
            bg="#475569", fg="white", activebackground="#334155", activeforeground="white",
            relief=tk.FLAT, cursor="hand2", pady=8, command=self.generate_passphrase
        )
        btn_passphrase.pack(side=tk.RIGHT, padx=(5, 0))

        # Right Column: In-Memory History (Last 5)
        hist_frame = tk.LabelFrame(bottom_box, text=" In-Memory Session History (Last 5) ", font=("Segoe UI", 10, "bold"), fg="#cbd5e1", bg="#1e293b", padx=15, pady=12, width=320)
        hist_frame.pack(side=tk.RIGHT, fill=tk.BOTH, padx=(10, 0))
        hist_frame.pack_propagate(False)

        lbl_sec = tk.Label(
            hist_frame, text="🔒 Non-Persistent: History clears immediately when the window is closed.",
            font=("Segoe UI", 8, "italic"), fg="#94a3b8", bg="#1e293b", wraplength=280
        )
        lbl_sec.pack(anchor="w", pady=(0, 8))

        self.history_box = tk.Frame(hist_frame, bg="#1e293b")
        self.history_box.pack(fill=tk.BOTH, expand=True)

    def _on_slider_changed(self, event=None):
        val = int(self.slider.get())
        self.length_var.set(val)
        self.lbl_len_display.config(text=str(val))

    def generate_password(self):
        length = self.length_var.get()

        # Validate minimum 8 characters enforced
        if length < 8:
            messagebox.showwarning("Validation Error", "Password length must be at least 8 characters.")
            return

        # Build character sets
        upper_chars = string.ascii_uppercase
        lower_chars = string.ascii_lowercase
        digit_chars = string.digits
        symbol_chars = "!@#$%^&*()-_=+[]{}|;:,.<>?"

        # Exclude ambiguous characters if selected
        ambiguous = "0Oo1lI|`'\"~,;:."
        if self.exclude_ambiguous.get():
            upper_chars = "".join([c for c in upper_chars if c not in ambiguous])
            lower_chars = "".join([c for c in lower_chars if c not in ambiguous])
            digit_chars = "".join([c for c in digit_chars if c not in ambiguous])
            symbol_chars = "".join([c for c in symbol_chars if c not in ambiguous])

        selected_pools = []
        guaranteed_chars = []

        if self.use_upper.get():
            selected_pools.append(upper_chars)
            guaranteed_chars.append(secrets.choice(upper_chars))
        if self.use_lower.get():
            selected_pools.append(lower_chars)
            guaranteed_chars.append(secrets.choice(lower_chars))
        if self.use_digits.get():
            selected_pools.append(digit_chars)
            guaranteed_chars.append(secrets.choice(digit_chars))
        if self.use_symbols.get():
            selected_pools.append(symbol_chars)
            guaranteed_chars.append(secrets.choice(symbol_chars))

        # PDF Requirement: At least 2 character types must be selected
        if len(selected_pools) < 2:
            messagebox.showwarning(
                "Complexity Requirement",
                "Please select at least 2 character types (Uppercase, Lowercase, Numbers, or Symbols) to ensure minimum cryptographic strength."
            )
            return

        # Combine all allowed characters
        full_pool = "".join(selected_pools)
        remaining_length = length - len(guaranteed_chars)

        # Fill remaining characters using secrets.choice (CSPRNG)
        password_chars = guaranteed_chars + [secrets.choice(full_pool) for _ in range(remaining_length)]

        # Cryptographically secure shuffle using Fisher-Yates with secrets.randbelow
        for i in range(len(password_chars) - 1, 0, -1):
            j = secrets.randbelow(i + 1)
            password_chars[i], password_chars[j] = password_chars[j], password_chars[i]

        password = "".join(password_chars)

        # Update Display Entry
        self.pass_entry.delete(0, tk.END)
        self.pass_entry.insert(0, password)

        # Calculate Strength & Entropy
        self._evaluate_strength(password, len(full_pool))

        # Add to session history
        self._add_to_history(password)

        # Auto copy if enabled
        if self.auto_copy.get():
            self._copy_silent(password)
            self._show_toast("⚡ Generated & Auto-Copied to Clipboard!")
        else:
            self._show_toast("✅ Secure password generated successfully.")

    def generate_passphrase(self):
        # Generates a 4-word memorable passphrase with separators and a secret number
        words = [secrets.choice(PASSPHRASE_WORDS).capitalize() for _ in range(4)]
        sep = secrets.choice(["-", "_", ".", "$"])
        num = secrets.randbelow(90) + 10
        passphrase = f"{sep.join(words)}{sep}{num}"

        self.pass_entry.delete(0, tk.END)
        self.pass_entry.insert(0, passphrase)

        pool_size = len(PASSPHRASE_WORDS)
        entropy = round(4 * math.log2(pool_size) + math.log2(90), 1)

        self._render_strength_ui("Strong Passphrase (XKCD Style)", "#38bdf8", 0.85, entropy)
        self._add_to_history(passphrase)

        if self.auto_copy.get():
            self._copy_silent(passphrase)
            self._show_toast("⚡ Passphrase Generated & Copied!")

    def _evaluate_strength(self, pwd, pool_size):
        length = len(pwd)
        entropy = round(length * math.log2(max(pool_size, 2)), 1)

        # Calculate score based on length and entropy
        if entropy < 40 or length < 8:
            rating = "Weak (Vulnerable)"
            color = "#ef4444"
            ratio = 0.25
        elif entropy < 60:
            rating = "Medium (Fair)"
            color = "#f59e0b"
            ratio = 0.55
        elif entropy < 85:
            rating = "Strong (Secure)"
            color = "#10b981"
            ratio = 0.82
        else:
            rating = "Maximum (Military Grade)"
            color = "#38bdf8"
            ratio = 1.0

        self._render_strength_ui(rating, color, ratio, entropy)

    def _render_strength_ui(self, rating, color, ratio, entropy):
        self.lbl_strength.config(text=f"Strength: {rating}", fg=color)
        self.lbl_entropy.config(text=f"Entropy: {entropy} bits")

        self.strength_canvas.delete("all")
        w = self.strength_canvas.winfo_width() or 400
        h = 8
        fill_w = int(w * ratio)
        self.strength_canvas.create_rectangle(0, 0, fill_w, h, fill=color, outline="")

    def _add_to_history(self, pwd):
        self.last_passwords.insert(0, pwd)
        if len(self.last_passwords) > 5:
            self.last_passwords = self.last_passwords[:5]

        # Redraw history widgets
        for widget in self.history_box.winfo_children():
            widget.destroy()

        for idx, p in enumerate(self.last_passwords):
            row = tk.Frame(self.history_box, bg="#0b1329", bd=1, relief=tk.SOLID)
            row.pack(fill=tk.X, pady=3)

            masked = p if len(p) <= 14 else (p[:6] + "•••" + p[-4:])
            lbl = tk.Label(row, text=f"#{idx+1} {masked}", font=("Consolas", 9), fg="#94a3b8", bg="#0b1329")
            lbl.pack(side=tk.LEFT, padx=8, pady=4)

            btn = tk.Button(
                row, text="Copy", font=("Segoe UI", 7, "bold"),
                bg="#334155", fg="#e2e8f0", relief=tk.FLAT, cursor="hand2",
                command=lambda val=p: self._copy_specific(val)
            )
            btn.pack(side=tk.RIGHT, padx=6, pady=2)

    def _copy_silent(self, text):
        try:
            self.root.clipboard_clear()
            self.root.clipboard_append(text)
            self.root.update()
        except Exception as e:
            print(f"Clipboard error: {e}")

    def copy_to_clipboard(self):
        pwd = self.pass_entry.get().strip()
        if not pwd:
            return
        self._copy_silent(pwd)
        self._show_toast("📋 Password successfully copied to clipboard!")

    def _copy_specific(self, text):
        self._copy_silent(text)
        self._show_toast(f"📋 Copied previous password to clipboard!")

    def _show_toast(self, message):
        self.lbl_toast.config(text=message)
        self.root.after(3500, lambda: self.lbl_toast.config(text=""))


if __name__ == "__main__":
    root = tk.Tk()
    app = PasswordGeneratorApp(root)
    root.mainloop()
