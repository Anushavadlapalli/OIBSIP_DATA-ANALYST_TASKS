"""
Oasis Infobyte Internship - Task 2: BMI Calculator (Advanced Tier)
Author: OIBSIP Intern
Features:
- GUI built with modern Tkinter styling
- Dual Unit Support: Metric (kg, cm/m) & Imperial (lbs, ft+in)
- Real-time BMI calculation & WHO health category classification
- Color-coded visual health status gauge
- Multi-user management (switch between profiles, add new users)
- Persistent SQLite database (records timestamp, weight, height, BMI, category)
- Embedded Matplotlib interactive BMI trend line chart over time
- CSV data export & record deletion controls
- Robust input validation and error handling
"""

import sys
import os
import sqlite3
import datetime
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

# Set MPLCONFIGDIR to temporary writable folder to avoid warnings
os.environ["MPLCONFIGDIR"] = os.path.join(os.environ.get("TEMP", "."), "matplotlib_cache")

import matplotlib
matplotlib.use("TkAgg")
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

DB_PATH = os.path.join(os.path.dirname(__file__), "bmi_records.db")

def init_db():
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS bmi_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                weight_kg REAL NOT NULL,
                height_cm REAL NOT NULL,
                bmi REAL NOT NULL,
                category TEXT NOT NULL,
                logged_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        """)
        # Insert default user if empty
        cursor.execute("SELECT COUNT(*) FROM users")
        if cursor.fetchone()[0] == 0:
            cursor.execute("INSERT INTO users (username) VALUES (?)", ("Default User",))
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"Database init error: {e}")

init_db()


class BMICalculatorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("BodyStat Pro - Advanced BMI Health & Trend Suite")
        self.root.geometry("980x720")
        self.root.minsize(880, 640)
        self.root.configure(bg="#0f172a")

        self.unit_mode = tk.StringVar(value="Metric (kg, cm)")
        self.current_user_id = None
        self.current_username = ""

        self._build_ui()
        self._load_users()

    def _build_ui(self):
        # Header Bar
        header = tk.Frame(self.root, bg="#1e293b", height=70)
        header.pack(fill=tk.X, side=tk.TOP)
        header.pack_propagate(False)

        title_frame = tk.Frame(header, bg="#1e293b")
        title_frame.pack(side=tk.LEFT, padx=20, pady=12)

        lbl_title = tk.Label(
            title_frame, text="📊 BODYSTAT PRO • BMI ANALYZER",
            font=("Segoe UI", 16, "bold"), fg="#38bdf8", bg="#1e293b"
        )
        lbl_title.pack(anchor="w")

        lbl_sub = tk.Label(
            title_frame, text="Oasis Infobyte Internship Task 2 • Advanced Tier with Trend Analytics",
            font=("Segoe UI", 9), fg="#94a3b8", bg="#1e293b"
        )
        lbl_sub.pack(anchor="w")

        # User Switcher in Header
        user_frame = tk.Frame(header, bg="#1e293b")
        user_frame.pack(side=tk.RIGHT, padx=20, pady=15)

        tk.Label(user_frame, text="👤 Profile:", font=("Segoe UI", 10, "bold"), fg="#cbd5e1", bg="#1e293b").pack(side=tk.LEFT, padx=(0, 6))
        self.user_combo = ttk.Combobox(user_frame, state="readonly", width=16, font=("Segoe UI", 9))
        self.user_combo.pack(side=tk.LEFT, padx=(0, 6))
        self.user_combo.bind("<<ComboboxSelected>>", self._on_user_selected)

        btn_add_user = tk.Button(
            user_frame, text="➕ New", font=("Segoe UI", 8, "bold"),
            bg="#2563eb", fg="white", relief=tk.FLAT, cursor="hand2", command=self._prompt_add_user
        )
        btn_add_user.pack(side=tk.LEFT)

        # Main Layout: Left Controls / Inputs, Right: Gauge + History Graph Tabs
        body = tk.Frame(self.root, bg="#0f172a")
        body.pack(fill=tk.BOTH, expand=True, padx=20, pady=15)

        # Left Column (Input Form)
        left_col = tk.Frame(body, bg="#1e293b", width=340, bd=1, relief=tk.SOLID)
        left_col.pack(side=tk.LEFT, fill=tk.BOTH, padx=(0, 15))
        left_col.pack_propagate(False)

        lbl_form = tk.Label(left_col, text="Enter Body Measurements", font=("Segoe UI", 11, "bold"), fg="#f8fafc", bg="#1e293b")
        lbl_form.pack(anchor="w", padx=15, pady=(15, 10))

        # Unit Selection
        unit_frame = tk.LabelFrame(left_col, text=" Unit System ", font=("Segoe UI", 9, "bold"), fg="#94a3b8", bg="#1e293b", padx=10, pady=8)
        unit_frame.pack(fill=tk.X, padx=15, pady=(0, 12))

        rb_metric = tk.Radiobutton(
            unit_frame, text="Metric (kg, cm)", variable=self.unit_mode,
            value="Metric (kg, cm)", font=("Segoe UI", 9), fg="#e2e8f0", bg="#1e293b",
            selectcolor="#0f172a", activebackground="#1e293b", activeforeground="white",
            command=self._update_unit_labels
        )
        rb_metric.pack(anchor="w")

        rb_imp = tk.Radiobutton(
            unit_frame, text="Imperial (lbs, ft + in)", variable=self.unit_mode,
            value="Imperial (lbs, ft + in)", font=("Segoe UI", 9), fg="#e2e8f0", bg="#1e293b",
            selectcolor="#0f172a", activebackground="#1e293b", activeforeground="white",
            command=self._update_unit_labels
        )
        rb_imp.pack(anchor="w")

        # Inputs Form
        inputs_box = tk.Frame(left_col, bg="#1e293b")
        inputs_box.pack(fill=tk.X, padx=15)

        # Weight input
        self.lbl_weight = tk.Label(inputs_box, text="Weight (kg):", font=("Segoe UI", 9, "bold"), fg="#cbd5e1", bg="#1e293b")
        self.lbl_weight.pack(anchor="w", pady=(5, 2))
        self.entry_weight = tk.Entry(inputs_box, font=("Segoe UI", 11), bg="#0b1329", fg="#38bdf8", relief=tk.FLAT, bd=5)
        self.entry_weight.pack(fill=tk.X, pady=(0, 10))

        # Height inputs
        self.height_frame = tk.Frame(inputs_box, bg="#1e293b")
        self.height_frame.pack(fill=tk.X)

        self.lbl_height = tk.Label(self.height_frame, text="Height (cm):", font=("Segoe UI", 9, "bold"), fg="#cbd5e1", bg="#1e293b")
        self.lbl_height.pack(anchor="w", pady=(5, 2))

        self.entry_height = tk.Entry(self.height_frame, font=("Segoe UI", 11), bg="#0b1329", fg="#38bdf8", relief=tk.FLAT, bd=5)
        self.entry_height.pack(fill=tk.X, pady=(0, 10))

        # Additional entries for Imperial ft + in
        self.imp_height_frame = tk.Frame(self.height_frame, bg="#1e293b")
        self.entry_ft = tk.Entry(self.imp_height_frame, font=("Segoe UI", 11), bg="#0b1329", fg="#38bdf8", relief=tk.FLAT, bd=5, width=6)
        self.lbl_ft = tk.Label(self.imp_height_frame, text="ft", fg="#94a3b8", bg="#1e293b")
        self.entry_in = tk.Entry(self.imp_height_frame, font=("Segoe UI", 11), bg="#0b1329", fg="#38bdf8", relief=tk.FLAT, bd=5, width=6)
        self.lbl_in = tk.Label(self.imp_height_frame, text="in", fg="#94a3b8", bg="#1e293b")

        # Action Buttons
        btn_calc = tk.Button(
            left_col, text="⚡ CALCULATE & RECORD BMI", font=("Segoe UI", 10, "bold"),
            bg="#059669", fg="white", activebackground="#047857", activeforeground="white",
            relief=tk.FLAT, cursor="hand2", command=self.calculate_and_save
        )
        btn_calc.pack(fill=tk.X, padx=15, pady=12)

        # Quick Health Reference Card
        ref_frame = tk.LabelFrame(left_col, text=" WHO BMI Standard Ranges ", font=("Segoe UI", 8, "bold"), fg="#94a3b8", bg="#1e293b", padx=10, pady=8)
        ref_frame.pack(fill=tk.BOTH, expand=True, padx=15, pady=(0, 15))

        cats = [
            ("Underweight (< 18.5)", "#38bdf8"),
            ("Normal Weight (18.5 – 24.9)", "#10b981"),
            ("Overweight (25.0 – 29.9)", "#f59e0b"),
            ("Obese Class I (30.0 – 34.9)", "#f97316"),
            ("Obese Class II+ (≥ 35.0)", "#ef4444")
        ]
        for ctext, color in cats:
            row = tk.Frame(ref_frame, bg="#1e293b")
            row.pack(fill=tk.X, pady=2)
            tk.Label(row, text="■", font=("Segoe UI", 11), fg=color, bg="#1e293b").pack(side=tk.LEFT, padx=(0, 6))
            tk.Label(row, text=ctext, font=("Segoe UI", 8), fg="#cbd5e1", bg="#1e293b").pack(side=tk.LEFT)

        # Right Column (Tabs: Result Dashboard & Trend Graph)
        right_col = tk.Frame(body, bg="#1e293b", bd=1, relief=tk.SOLID)
        right_col.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        notebook_style = ttk.Style()
        notebook_style.theme_use("default")
        notebook_style.configure("TNotebook", background="#1e293b", borderwidth=0)
        notebook_style.configure("TNotebook.Tab", background="#334155", foreground="white", padding=[15, 6], font=("Segoe UI", 9, "bold"))
        notebook_style.map("TNotebook.Tab", background=[("selected", "#2563eb")], foreground=[("selected", "white")])

        self.tabs = ttk.Notebook(right_col)
        self.tabs.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Tab 1: Current Result & Gauge
        self.tab_result = tk.Frame(self.tabs, bg="#0b1329")
        self.tabs.add(self.tab_result, text="  Current Result & Analysis  ")

        # Tab 2: Matplotlib Trend History Chart
        self.tab_trend = tk.Frame(self.tabs, bg="#0b1329")
        self.tabs.add(self.tab_trend, text="  BMI Trend History (Graph)  ")

        # Tab 3: History Table & CSV Export
        self.tab_logs = tk.Frame(self.tabs, bg="#0b1329")
        self.tabs.add(self.tab_logs, text="  Historical Logs  ")

        self._build_tab_result()
        self._build_tab_trend()
        self._build_tab_logs()

    def _build_tab_result(self):
        card = tk.Frame(self.tab_result, bg="#111827", bd=1, relief=tk.SOLID)
        card.pack(fill=tk.BOTH, expand=True, padx=25, pady=20)

        self.lbl_res_val = tk.Label(card, text="--.-", font=("Segoe UI", 56, "bold"), fg="#94a3b8", bg="#111827")
        self.lbl_res_val.pack(pady=(25, 0))

        self.lbl_res_cat = tk.Label(card, text="ENTER DETAILS TO CALCULATE", font=("Segoe UI", 16, "bold"), fg="#64748b", bg="#111827")
        self.lbl_res_cat.pack(pady=(5, 15))

        # Visual Meter Bar
        meter_frame = tk.Frame(card, bg="#111827")
        meter_frame.pack(fill=tk.X, padx=50, pady=10)

        self.gauge_canvas = tk.Canvas(meter_frame, height=36, bg="#1f2937", highlightthickness=0)
        self.gauge_canvas.pack(fill=tk.X)
        self._draw_gauge(0)

        # Analysis details
        self.lbl_advice = tk.Label(
            card, text="Ideal healthy weight range and health tips will appear here after calculation.",
            font=("Segoe UI", 10), fg="#94a3b8", bg="#111827", wraplength=480, justify=tk.CENTER
        )
        self.lbl_advice.pack(pady=20)

    def _draw_gauge(self, bmi):
        self.gauge_canvas.delete("all")
        w = self.gauge_canvas.winfo_width() or 450
        h = 36

        # Draw segmented colored bar
        # Underweight (15 to 18.5), Normal (18.5 to 25), Overweight (25 to 30), Obese (30 to 40)
        # Total scale 15 to 40 = 25 units
        def scale(val):
            ratio = max(0.0, min(1.0, (val - 15) / 25))
            return int(ratio * w)

        x_under = scale(18.5)
        x_norm = scale(25.0)
        x_over = scale(30.0)

        self.gauge_canvas.create_rectangle(0, 0, x_under, h, fill="#0284c7", outline="")
        self.gauge_canvas.create_rectangle(x_under, 0, x_norm, h, fill="#10b981", outline="")
        self.gauge_canvas.create_rectangle(x_norm, 0, x_over, h, fill="#f59e0b", outline="")
        self.gauge_canvas.create_rectangle(x_over, 0, w, h, fill="#ef4444", outline="")

        if bmi > 0:
            cx = scale(bmi)
            self.gauge_canvas.create_line(cx, 0, cx, h, fill="white", width=4)
            self.gauge_canvas.create_polygon(cx-6, 0, cx+6, 0, cx, 8, fill="white")
            self.gauge_canvas.create_polygon(cx-6, h, cx+6, h, cx, h-8, fill="white")

    def _build_tab_trend(self):
        self.chart_frame = tk.Frame(self.tab_trend, bg="#0b1329")
        self.chart_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        self.figure = Figure(figsize=(6, 4), dpi=100, facecolor="#0b1329")
        self.ax = self.figure.add_subplot(111)
        self.ax.set_facecolor("#0f172a")
        self.canvas_chart = FigureCanvasTkAgg(self.figure, master=self.chart_frame)
        self.canvas_chart.get_tk_widget().pack(fill=tk.BOTH, expand=True)

    def _build_tab_logs(self):
        top_bar = tk.Frame(self.tab_logs, bg="#0b1329")
        top_bar.pack(fill=tk.X, padx=15, pady=8)

        btn_export = tk.Button(
            top_bar, text="📥 Export to CSV", font=("Segoe UI", 9, "bold"),
            bg="#2563eb", fg="white", relief=tk.FLAT, cursor="hand2", command=self.export_csv
        )
        btn_export.pack(side=tk.LEFT)

        btn_del = tk.Button(
            top_bar, text="🗑️ Delete Selected", font=("Segoe UI", 9),
            bg="#dc2626", fg="white", relief=tk.FLAT, cursor="hand2", command=self.delete_selected_log
        )
        btn_del.pack(side=tk.RIGHT)

        cols = ("id", "date", "weight", "height", "bmi", "category")
        self.log_tree = ttk.Treeview(self.tab_logs, columns=cols, show="headings", height=12)
        self.log_tree.heading("id", text="ID")
        self.log_tree.heading("date", text="Date & Time")
        self.log_tree.heading("weight", text="Weight (kg)")
        self.log_tree.heading("height", text="Height (cm)")
        self.log_tree.heading("bmi", text="BMI Value")
        self.log_tree.heading("category", text="Classification")

        self.log_tree.column("id", width=40, anchor="center")
        self.log_tree.column("date", width=160)
        self.log_tree.column("weight", width=90, anchor="center")
        self.log_tree.column("height", width=90, anchor="center")
        self.log_tree.column("bmi", width=90, anchor="center")
        self.log_tree.column("category", width=140, anchor="center")
        self.log_tree.pack(fill=tk.BOTH, expand=True, padx=15, pady=(0, 10))

    # --- Unit Mode Updates ---
    def _update_unit_labels(self):
        mode = self.unit_mode.get()
        if "Metric" in mode:
            self.lbl_weight.config(text="Weight (kg):")
            self.lbl_height.config(text="Height (cm):")
            self.imp_height_frame.pack_forget()
            self.entry_height.pack(fill=tk.X, pady=(0, 10))
        else:
            self.lbl_weight.config(text="Weight (lbs):")
            self.lbl_height.config(text="Height (ft & in):")
            self.entry_height.pack_forget()
            self.imp_height_frame.pack(fill=tk.X, pady=(0, 10))
            self.entry_ft.pack(side=tk.LEFT, padx=(0, 4))
            self.lbl_ft.pack(side=tk.LEFT, padx=(0, 10))
            self.entry_in.pack(side=tk.LEFT, padx=(0, 4))
            self.lbl_in.pack(side=tk.LEFT)

    # --- User Management ---
    def _load_users(self):
        try:
            conn = sqlite3.connect(DB_PATH)
            cur = conn.cursor()
            cur.execute("SELECT id, username FROM users ORDER BY id ASC")
            rows = cur.fetchall()
            conn.close()

            user_names = [r[1] for r in rows]
            self.user_combo["values"] = user_names
            if user_names:
                self.user_combo.current(0)
                self.current_user_id = rows[0][0]
                self.current_username = rows[0][1]
                self._refresh_user_data()
        except Exception as e:
            messagebox.showerror("Database Error", f"Failed to load user list: {e}")

    def _on_user_selected(self, event=None):
        name = self.user_combo.get()
        try:
            conn = sqlite3.connect(DB_PATH)
            cur = conn.cursor()
            cur.execute("SELECT id FROM users WHERE username = ?", (name,))
            row = cur.fetchone()
            conn.close()
            if row:
                self.current_user_id = row[0]
                self.current_username = name
                self._refresh_user_data()
        except Exception as e:
            print(f"User select error: {e}")

    def _prompt_add_user(self):
        dialog = tk.Toplevel(self.root)
        dialog.title("Create Profile")
        dialog.geometry("320x150")
        dialog.configure(bg="#1e293b")
        dialog.transient(self.root)
        dialog.grab_set()

        tk.Label(dialog, text="Enter New Profile Name:", font=("Segoe UI", 10, "bold"), fg="white", bg="#1e293b").pack(pady=12)
        entry = tk.Entry(dialog, font=("Segoe UI", 10), bg="#0b1329", fg="white", insertbackground="white")
        entry.pack(pady=5, padx=25, fill=tk.X)
        entry.focus_set()

        def submit():
            name = entry.get().strip()
            if not name:
                messagebox.showwarning("Validation", "Name cannot be empty.", parent=dialog)
                return
            try:
                conn = sqlite3.connect(DB_PATH)
                cur = conn.cursor()
                cur.execute("INSERT INTO users (username) VALUES (?)", (name,))
                conn.commit()
                conn.close()
                dialog.destroy()
                self._load_users()
                self.user_combo.set(name)
                self._on_user_selected()
            except sqlite3.IntegrityError:
                messagebox.showwarning("Exists", "A profile with this name already exists.", parent=dialog)
            except Exception as e:
                messagebox.showerror("Error", f"Could not create user: {e}", parent=dialog)

        tk.Button(dialog, text="Save Profile", bg="#059669", fg="white", font=("Segoe UI", 9, "bold"), relief=tk.FLAT, command=submit).pack(pady=10)

    # --- Calculation & Validation ---
    def calculate_and_save(self):
        mode = self.unit_mode.get()
        w_val = self.entry_weight.get().strip()

        # Validate Weight
        try:
            weight = float(w_val)
            if weight <= 0 or weight > 500:
                raise ValueError
        except ValueError:
            messagebox.showerror("Input Error", "Please enter a valid positive numeric weight (e.g. 70).")
            return

        # Validate Height
        if "Metric" in mode:
            h_val = self.entry_height.get().strip()
            try:
                height_cm = float(h_val)
                if height_cm < 50 or height_cm > 280:
                    raise ValueError
            except ValueError:
                messagebox.showerror("Input Error", "Please enter a valid height in cm between 50 and 280.")
                return
            weight_kg = weight
        else:
            ft_val = self.entry_ft.get().strip()
            in_val = self.entry_in.get().strip() or "0"
            try:
                feet = float(ft_val)
                inches = float(in_val)
                if feet < 1 or feet > 8 or inches < 0 or inches >= 12:
                    raise ValueError
                total_inches = (feet * 12) + inches
                height_cm = total_inches * 2.54
                weight_kg = weight * 0.45359237
            except ValueError:
                messagebox.showerror("Input Error", "Please enter valid feet (1-8) and inches (0-11).")
                return

        # Height in meters
        height_m = height_cm / 100.0
        bmi = weight_kg / (height_m ** 2)
        bmi = round(bmi, 2)

        # Classification
        if bmi < 18.5:
            cat = "Underweight"
            color = "#38bdf8"
        elif bmi <= 24.9:
            cat = "Normal Weight"
            color = "#10b981"
        elif bmi <= 29.9:
            cat = "Overweight"
            color = "#f59e0b"
        elif bmi <= 34.9:
            cat = "Obese Class I"
            color = "#f97316"
        else:
            cat = "Obese Class II+"
            color = "#ef4444"

        # Update Result View
        self.lbl_res_val.config(text=f"{bmi:.1f}", fg=color)
        self.lbl_res_cat.config(text=cat.upper(), fg=color)

        # Calculate Healthy Range
        min_healthy = round(18.5 * (height_m ** 2), 1)
        max_healthy = round(24.9 * (height_m ** 2), 1)
        advice = (
            f"💡 For your height of {height_cm:.0f} cm, the ideal healthy weight is between "
            f"{min_healthy} kg and {max_healthy} kg.\n"
        )
        if cat == "Normal Weight":
            advice += "🎉 Excellent! Your BMI falls within the healthy standard range."
        elif cat == "Underweight":
            diff = round(min_healthy - weight_kg, 1)
            advice += f"Consider a nutrient-rich diet to gain approximately {diff} kg."
        else:
            diff = round(weight_kg - max_healthy, 1)
            advice += f"Recommended target: Reduce approximately {diff} kg to enter the healthy range."

        self.lbl_advice.config(text=advice)
        self._draw_gauge(bmi)

        # Save to SQLite Database
        if self.current_user_id:
            try:
                conn = sqlite3.connect(DB_PATH)
                cur = conn.cursor()
                cur.execute("""
                    INSERT INTO bmi_logs (user_id, weight_kg, height_cm, bmi, category)
                    VALUES (?, ?, ?, ?, ?)
                """, (self.current_user_id, round(weight_kg, 2), round(height_cm, 1), bmi, cat))
                conn.commit()
                conn.close()
                self._refresh_user_data()
            except Exception as e:
                messagebox.showerror("Database Error", f"Failed to persist BMI record: {e}")

    # --- Data & Trend Refresh ---
    def _refresh_user_data(self):
        if not self.current_user_id:
            return

        # Fetch records
        try:
            conn = sqlite3.connect(DB_PATH)
            cur = conn.cursor()
            cur.execute("""
                SELECT id, logged_at, weight_kg, height_cm, bmi, category
                FROM bmi_logs
                WHERE user_id = ?
                ORDER BY logged_at ASC
            """, (self.current_user_id,))
            rows = cur.fetchall()
            conn.close()

            # Refresh Treeview
            for item in self.log_tree.get_children():
                self.log_tree.delete(item)
            for r in reversed(rows):
                self.log_tree.insert("", tk.END, values=r)

            # Refresh Matplotlib Trend Chart
            self._render_trend_chart(rows)

        except Exception as e:
            print(f"Refresh error: {e}")

    def _render_trend_chart(self, rows):
        self.ax.clear()
        self.ax.set_facecolor("#0f172a")

        if len(rows) < 2:
            self.ax.text(
                0.5, 0.5, "Log at least 2 records to view BMI trend line graph.",
                color="#64748b", ha="center", va="center", transform=self.ax.transAxes,
                fontsize=11
            )
        else:
            indices = list(range(1, len(rows) + 1))
            bmis = [r[4] for r in rows]

            # Plot BMI line
            self.ax.plot(indices, bmis, marker="o", color="#38bdf8", linewidth=2.5, label="User BMI")

            # Healthy threshold lines
            self.ax.axhline(18.5, color="#10b981", linestyle="--", alpha=0.6, label="Normal Min (18.5)")
            self.ax.axhline(25.0, color="#f59e0b", linestyle="--", alpha=0.6, label="Overweight (25.0)")
            self.ax.axhline(30.0, color="#ef4444", linestyle="--", alpha=0.6, label="Obese (30.0)")

            self.ax.set_title(f"BMI Progress Over Time: {self.current_username}", color="#f8fafc", fontsize=11, fontweight="bold")
            self.ax.set_xlabel("Recorded Session #", color="#94a3b8", fontsize=9)
            self.ax.set_ylabel("BMI Value", color="#94a3b8", fontsize=9)
            self.ax.tick_params(colors="#94a3b8")
            self.ax.grid(True, linestyle=":", alpha=0.3, color="#475569")
            self.ax.legend(facecolor="#1e293b", edgecolor="#334155", labelcolor="#e2e8f0", fontsize=8)

        self.figure.tight_layout()
        self.canvas_chart.draw()

    def export_csv(self):
        if not self.current_user_id:
            return
        file_path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV Files", "*.csv")],
            initialfile=f"{self.current_username}_bmi_history.csv"
        )
        if not file_path:
            return

        try:
            import csv
            conn = sqlite3.connect(DB_PATH)
            cur = conn.cursor()
            cur.execute("""
                SELECT id, logged_at, weight_kg, height_cm, bmi, category
                FROM bmi_logs WHERE user_id = ? ORDER BY logged_at ASC
            """, (self.current_user_id,))
            rows = cur.fetchall()
            conn.close()

            with open(file_path, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow(["Record_ID", "Timestamp", "Weight_KG", "Height_CM", "BMI", "Classification"])
                writer.writerows(rows)

            messagebox.showinfo("Export Successful", f"Exported {len(rows)} records to:\n{file_path}")
        except Exception as e:
            messagebox.showerror("Export Failed", f"Error saving CSV: {e}")

    def delete_selected_log(self):
        selected = self.log_tree.selection()
        if not selected:
            messagebox.showwarning("Select Record", "Please select a record from the table to delete.")
            return

        item = self.log_tree.item(selected[0])
        rec_id = item["values"][0]

        if messagebox.askyesno("Confirm Deletion", f"Are you sure you want to delete record #{rec_id}?"):
            try:
                conn = sqlite3.connect(DB_PATH)
                cur = conn.cursor()
                cur.execute("DELETE FROM bmi_logs WHERE id = ?", (rec_id,))
                conn.commit()
                conn.close()
                self._refresh_user_data()
            except Exception as e:
                messagebox.showerror("Delete Error", f"Failed to delete record: {e}")


if __name__ == "__main__":
    root = tk.Tk()
    app = BMICalculatorApp(root)
    root.mainloop()
