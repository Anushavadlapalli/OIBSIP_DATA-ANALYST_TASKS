# OIBSIP — Python Programming Task 2: BMI Calculator & Health Analytics (Advanced Tier)

![Python](https://img.shields.io/badge/Python-3.8%2B-blue.svg)
![GUI](https://img.shields.io/badge/GUI-Tkinter-green.svg)
![Matplotlib](https://img.shields.io/badge/Data%20Viz-Matplotlib-orange.svg)
![Database](https://img.shields.io/badge/Storage-SQLite3-lightgrey.svg)
![Status](https://img.shields.io/badge/Status-Completed-success.svg)

---

## 📌 Project Overview
**BodyStat Pro** is an advanced Body Mass Index (BMI) calculator, health assessment, and longitudinal trend analysis application developed for the Oasis Infobyte Internship (Python Programming Track).

Unlike simple command-line tools, this application implements a full graphical user interface (Tkinter), dual-unit support (Metric & Imperial), WHO standard health classifications, multi-user profiles, persistent local SQLite database storage, dynamic interactive Matplotlib trend visualization, and 1-click CSV export.

---

## 📐 Scientific Formula & Classification
$$BMI = \frac{\text{Weight (kg)}}{[\text{Height (m)}]^2}$$

| BMI Range | WHO Classification | Risk / Advice Level |
| :--- | :--- | :--- |
| **< 18.5** | Underweight | Nutritional support recommended |
| **18.5 – 24.9** | Normal Weight | Optimal health range |
| **25.0 – 29.9** | Overweight | Increased cardiovascular risk |
| **30.0 – 34.9** | Obese Class I | High risk — lifestyle intervention |
| **≥ 35.0** | Obese Class II+ | Very high risk — medical consultation |

---

## ✨ Features Checklist

### Beginner Tier
- [x] **Height & Weight Capture**: Comprehensive input handling with clean labels.
- [x] **Accurate BMI Computation**: Implements standard formula rounded to 2 decimal places.
- [x] **WHO Classification Engine**: Accurately categorizes values into Underweight, Normal, Overweight, Obese.
- [x] **Robust Input Validation**: Rejects non-numeric, negative, or physiologically impossible numbers with informative alerts.

### Advanced Tier
- [x] **Modern Graphical Interface**: Built using Tkinter with a dark navy dashboard theme.
- [x] **Dual Unit Flexibility**: Switch between Metric (kg, cm) and Imperial (lbs, feet + inches) seamlessly.
- [x] **Dynamic Color-Coded Gauge**: Visual progress needle indicator matching health severity colors.
- [x] **Multi-User Profile Management**: Add and switch between named user profiles (e.g. family members/clients).
- [x] **SQLite Database Persistence**: Secure local relational storage preserving timestamps, weights, heights, BMIs, and categories.
- [x] **Interactive Matplotlib Trend Graph**: Plots a user's BMI trajectory across multiple recording sessions with benchmark threshold lines.
- [x] **CSV Data Export & Log Manager**: Export records to standard CSV files and delete individual logs.

---

## 🚀 How to Run

### Prerequisites
Make sure Python 3.8+ is installed with `matplotlib`:
```bash
pip install matplotlib
```

### Execution
Run the standalone BMI Calculator:
```bash
python bmi_calculator.py
```

---

## 📹 Screen Recording Walkthrough Script (for Task Submission)

> **⚠️ OASIS INFOBYTE REQUIREMENT**: The video must begin with a clear 2-second static title card displaying:
> 1. Full Name
> 2. Assigned Track: **Python Programming**
> 3. Task Title: **Task 2 - BMI Calculator**

### Video Step-by-Step Flow:
1. **[0:00 - 0:02]** Static title card showing Name, Track, and Task Title.
2. **[0:03 - 0:15]** Launch `bmi_calculator.py`. Create a new user profile (e.g., "Rahul").
3. **[0:16 - 0:35]** Enter weight: `72 kg` and height: `175 cm`. Click **Calculate & Record BMI**. Show result (`23.51 Normal Weight`), green gauge needle, and ideal weight target.
4. **[0:36 - 0:50]** Switch to **Imperial (lbs, ft+in)**. Enter `190 lbs`, `5 ft 9 in`. Show recalculation and updated category (`28.06 Overweight`).
5. **[0:51 - 1:10]** Switch to the **BMI Trend History (Graph)** tab. Show the interactive Matplotlib line chart demonstrating BMI trend over time.
6. **[1:11 - 1:25]** Switch to **Historical Logs** tab. Demonstrate the SQLite data table, delete a record, and click **Export to CSV**.
7. **[1:26 - 1:30]** Conclude walkthrough.

---

## 💼 LinkedIn Submission Post Template

```text
Delighted to share that I have completed Task 2: "Advanced BMI Calculator & Health Analytics" in the Python Programming track at Oasis Infobyte (OIBSIP)! 🚀

Project: BodyStat Pro - Modern BMI Health Suite
Tech Stack: Python, Tkinter, Matplotlib, SQLite3, CSV, Object-Oriented Programming

Key Highlights:
✨ Dual Unit Support: Metric (kg/cm) and Imperial (lbs/ft-in)
✨ Real-time WHO BMI health classification & dynamic color-coded visual gauge
✨ Multi-user profile management with personalized progress tracking
✨ Persistent local SQLite database storage for longitudinal records
✨ Embedded interactive Matplotlib trend visualization showing health trajectory
✨ 1-click CSV data export & record management

Check out the full source code on GitHub:
🔗 https://github.com/YOUR_USERNAME/OIBSIP

Thank you @Oasis Infobyte for this enriching challenge!

#oasisinfobyte #internship #python #datavisualization #matplotlib #sqlite #tkinter #healthtech
```
