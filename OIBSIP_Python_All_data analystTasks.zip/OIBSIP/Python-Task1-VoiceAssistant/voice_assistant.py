"""
Oasis Infobyte Internship - Task 1: Voice Assistant (Advanced Tier)
Author: OIBSIP Intern
Features:
- Speech Recognition (Microphone input + Typed voice command fallback)
- Text-to-Speech (SAPI.SpVoice / pyttsx3 / gTTS fallback)
- Voice commands: Greetings, Time/Date, Web Search, Weather, Wikipedia/QA, Reminders, Send Email simulation
- Custom command rules management (persistent JSON config)
- Modern Dark-Themed GUI with animated audio visualizer waves & command chips
- Complete Logging & Speech Activity Status
"""

import sys
import os
import json
import time
import math
import random
import threading
import datetime
import webbrowser
import smtplib
from email.mime.text import MIMEText
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext

# Speech Synthesis Engine setup
class SpeechEngine:
    def __init__(self):
        self.engine_type = None
        self._sapi = None
        self._pyttsx = None
        self._init_engine()

    def _init_engine(self):
        # Try win32com SAPI first (native on Windows, zero latency)
        try:
            import win32com.client
            self._sapi = win32com.client.Dispatch("SAPI.SpVoice")
            self.engine_type = "sapi"
            return
        except Exception:
            pass

        # Try pyttsx3
        try:
            import pyttsx3
            self._pyttsx = pyttsx3.init()
            self._pyttsx.setProperty('rate', 175)
            self.engine_type = "pyttsx3"
            return
        except Exception:
            pass

        self.engine_type = "silent"

    def speak(self, text):
        if not text:
            return
        try:
            if self.engine_type == "sapi" and self._sapi:
                self._sapi.Speak(text)
            elif self.engine_type == "pyttsx3" and self._pyttsx:
                self._pyttsx.say(text)
                self._pyttsx.runAndWait()
            else:
                print(f"[VoiceAssistant TTS]: {text}")
        except Exception as e:
            print(f"TTS error: {e}")

# Persistent Custom Commands Config
CONFIG_FILE = os.path.join(os.path.dirname(__file__), "custom_commands.json")

DEFAULT_COMMANDS = {
    "who made you": "I was developed for the Oasis Infobyte SIP Python Programming Internship.",
    "what can you do": "I can tell the time, date, weather, search the web, set reminders, answer questions, and execute custom commands.",
    "quote": "The mind is everything. What you think you become. - Buddha",
    "tell me a joke": "Why do programmers prefer dark mode? Because light attracts bugs!"
}

def load_custom_commands():
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return DEFAULT_COMMANDS.copy()

def save_custom_commands(cmds):
    try:
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(cmds, f, indent=4)
    except Exception as e:
        print(f"Failed to save custom commands: {e}")


class VoiceAssistantApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Aura - Oasis Infobyte AI Voice Assistant")
        self.root.geometry("820x680")
        self.root.minsize(750, 600)
        self.root.configure(bg="#0f172a")

        self.tts = SpeechEngine()
        self.custom_commands = load_custom_commands()
        self.is_listening = False
        self.visualizer_active = False
        self.wave_phase = 0.0
        self.reminders = []

        self._build_ui()
        self._start_reminder_checker()

        # Initial Welcome Greeting
        self.root.after(800, self._initial_greeting)

    def _build_ui(self):
        # Top Header Bar
        header = tk.Frame(self.root, bg="#1e293b", height=70)
        header.pack(fill=tk.X, side=tk.TOP)
        header.pack_propagate(False)

        title_frame = tk.Frame(header, bg="#1e293b")
        title_frame.pack(side=tk.LEFT, padx=20, pady=12)

        lbl_title = tk.Label(
            title_frame, text="⚡ AURA VOICE ASSISTANT",
            font=("Segoe UI", 16, "bold"), fg="#38bdf8", bg="#1e293b"
        )
        lbl_title.pack(anchor="w")

        lbl_sub = tk.Label(
            title_frame, text="Oasis Infobyte Internship Task 1 • Python Advanced Tier",
            font=("Segoe UI", 9), fg="#94a3b8", bg="#1e293b"
        )
        lbl_sub.pack(anchor="w")

        # Status Badge
        self.status_badge = tk.Label(
            header, text="● READY", font=("Segoe UI", 10, "bold"),
            fg="#10b981", bg="#1e293b", padx=15
        )
        self.status_badge.pack(side=tk.RIGHT, pady=20)

        # Main Body Frame (split into Left Controls & Right Conversation)
        body = tk.Frame(self.root, bg="#0f172a")
        body.pack(fill=tk.BOTH, expand=True, padx=20, pady=15)

        # Left Column: Visualizer, Voice Button, Quick Prompts
        left_col = tk.Frame(body, bg="#1e293b", width=320, bd=1, relief=tk.SOLID)
        left_col.pack(side=tk.LEFT, fill=tk.BOTH, padx=(0, 10))
        left_col.pack_propagate(False)

        # Visualizer Canvas
        vis_lbl = tk.Label(left_col, text="Audio Waveform Monitor", font=("Segoe UI", 10, "bold"), fg="#e2e8f0", bg="#1e293b")
        vis_lbl.pack(anchor="w", padx=15, pady=(15, 5))

        self.canvas = tk.Canvas(left_col, height=110, bg="#0b1329", highlightthickness=0)
        self.canvas.pack(fill=tk.X, padx=15, pady=5)
        self._draw_idle_waveform()

        # Listen / Mic Button
        self.btn_listen = tk.Button(
            left_col, text="🎙️ START LISTENING", font=("Segoe UI", 12, "bold"),
            bg="#2563eb", fg="white", activebackground="#1d4ed8", activeforeground="white",
            relief=tk.FLAT, cursor="hand2", command=self.toggle_listening
        )
        self.btn_listen.pack(fill=tk.X, padx=15, pady=12)

        # Quick Commands Frame
        chips_lbl = tk.Label(left_col, text="Quick Voice Prompts:", font=("Segoe UI", 10, "bold"), fg="#cbd5e1", bg="#1e293b")
        chips_lbl.pack(anchor="w", padx=15, pady=(5, 5))

        quick_prompts = [
            ("🕒 Current Time", "what time is it"),
            ("📅 Today's Date", "what is today's date"),
            ("🌤️ Weather Report", "how is the weather"),
            ("🔍 Web Search", "search python oasis infobyte"),
            ("⏰ Set 5s Reminder", "remind me in 5 seconds test alert"),
            ("📧 Send Email Test", "send test email to oasis"),
            ("😂 Tell a Joke", "tell me a joke"),
            ("💡 Add Custom Rule", "_open_rule_editor")
        ]

        chips_frame = tk.Frame(left_col, bg="#1e293b")
        chips_frame.pack(fill=tk.BOTH, expand=True, padx=15, pady=(0, 15))

        for text, prompt in quick_prompts:
            if prompt == "_open_rule_editor":
                btn = tk.Button(
                    chips_frame, text=text, font=("Segoe UI", 9, "bold"),
                    bg="#0284c7", fg="white", relief=tk.FLAT, cursor="hand2",
                    anchor="w", padx=8, pady=4, command=self.open_custom_command_dialog
                )
            else:
                btn = tk.Button(
                    chips_frame, text=text, font=("Segoe UI", 9),
                    bg="#334155", fg="#f8fafc", activebackground="#475569", activeforeground="white",
                    relief=tk.FLAT, cursor="hand2", anchor="w", padx=8, pady=3,
                    command=lambda p=prompt: self.execute_prompt(p)
                )
            btn.pack(fill=tk.X, pady=2)

        # Right Column: Conversation Log and Input Entry
        right_col = tk.Frame(body, bg="#1e293b", bd=1, relief=tk.SOLID)
        right_col.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        log_lbl = tk.Label(right_col, text="Voice Dialogue & Activity Log", font=("Segoe UI", 10, "bold"), fg="#e2e8f0", bg="#1e293b")
        log_lbl.pack(anchor="w", padx=15, pady=(15, 5))

        self.chat_display = scrolledtext.ScrolledText(
            right_col, wrap=tk.WORD, font=("Consolas", 10),
            bg="#0b1329", fg="#f1f5f9", insertbackground="#38bdf8",
            bd=0, padx=12, pady=10
        )
        self.chat_display.pack(fill=tk.BOTH, expand=True, padx=15, pady=5)
        self.chat_display.tag_config("user", foreground="#38bdf8", font=("Consolas", 10, "bold"))
        self.chat_display.tag_config("aura", foreground="#34d399", font=("Consolas", 10))
        self.chat_display.tag_config("sys", foreground="#94a3b8", font=("Consolas", 9, "italic"))
        self.chat_display.tag_config("alert", foreground="#f87171", font=("Consolas", 10, "bold"))
        self.chat_display.config(state=tk.DISABLED)

        # Text Command Input Bar (graceful fallback when no microphone or noisy environment)
        input_bar = tk.Frame(right_col, bg="#1e293b")
        input_bar.pack(fill=tk.X, padx=15, pady=12)

        self.cmd_entry = tk.Entry(
            input_bar, font=("Segoe UI", 10), bg="#0b1329", fg="#f8fafc",
            insertbackground="#38bdf8", relief=tk.FLAT, bd=6
        )
        self.cmd_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 8))
        self.cmd_entry.bind("<Return>", lambda e: self.on_text_submit())

        btn_send = tk.Button(
            input_bar, text="Send 🚀", font=("Segoe UI", 9, "bold"),
            bg="#059669", fg="white", activebackground="#047857", activeforeground="white",
            relief=tk.FLAT, padx=14, cursor="hand2", command=self.on_text_submit
        )
        btn_send.pack(side=tk.RIGHT)

        # Bottom Bar: System & Privacy Info
        footer = tk.Frame(self.root, bg="#0f172a", height=30)
        footer.pack(fill=tk.X, side=tk.BOTTOM, padx=20, pady=(0, 10))

        lbl_privacy = tk.Label(
            footer, text="🔒 Privacy Assured: Audio processed in-memory only. No audio files or personal data stored externally.",
            font=("Segoe UI", 8), fg="#64748b", bg="#0f172a"
        )
        lbl_privacy.pack(side=tk.LEFT)

        btn_clear = tk.Button(
            footer, text="Clear Log", font=("Segoe UI", 8), bg="#334155", fg="#cbd5e1",
            relief=tk.FLAT, cursor="hand2", command=self.clear_log
        )
        btn_clear.pack(side=tk.RIGHT)

    def _initial_greeting(self):
        greeting = "Hello! I am Aura, your Oasis Infobyte AI Voice Assistant. How can I help you today?"
        self.append_log("Aura", greeting, tag="aura")
        threading.Thread(target=self.tts.speak, args=(greeting,), daemon=True).start()

    def append_log(self, sender, text, tag="sys"):
        self.chat_display.config(state=tk.NORMAL)
        timestamp = datetime.datetime.now().strftime("%H:%M:%S")
        if sender:
            self.chat_display.insert(tk.END, f"[{timestamp}] {sender}: ", tag)
            self.chat_display.insert(tk.END, f"{text}\n\n")
        else:
            self.chat_display.insert(tk.END, f"[{timestamp}] {text}\n\n", tag)
        self.chat_display.see(tk.END)
        self.chat_display.config(state=tk.DISABLED)

    def clear_log(self):
        self.chat_display.config(state=tk.NORMAL)
        self.chat_display.delete(1.0, tk.END)
        self.chat_display.config(state=tk.DISABLED)

    def set_status(self, text, color="#10b981"):
        self.status_badge.config(text=f"● {text.upper()}", fg=color)

    # --- Waveform Visualizer ---
    def _draw_idle_waveform(self):
        self.canvas.delete("all")
        w = self.canvas.winfo_width() or 290
        h = self.canvas.winfo_height() or 110
        mid = h // 2
        points = []
        for x in range(0, w, 6):
            y = mid + int(4 * math.sin((x + self.wave_phase * 20) * 0.05))
            points.extend([x, y])
        if len(points) >= 4:
            self.canvas.create_line(points, fill="#334155", width=2, smooth=True)

    def _animate_waveform(self):
        if not self.visualizer_active:
            self._draw_idle_waveform()
            return

        self.canvas.delete("all")
        w = self.canvas.winfo_width() or 290
        h = self.canvas.winfo_height() or 110
        mid = h // 2
        self.wave_phase += 0.35

        # Draw dynamic animated waves
        points1 = []
        points2 = []
        for x in range(0, w, 5):
            amp = random.randint(15, 38)
            y1 = mid + int(amp * math.sin((x * 0.05) + self.wave_phase))
            y2 = mid - int((amp * 0.7) * math.cos((x * 0.04) + self.wave_phase))
            points1.extend([x, y1])
            points2.extend([x, y2])

        if len(points1) >= 4:
            self.canvas.create_line(points1, fill="#38bdf8", width=3, smooth=True)
            self.canvas.create_line(points2, fill="#a855f7", width=2, smooth=True)

        self.root.after(50, self._animate_waveform)

    # --- Voice Listening & Execution ---
    def toggle_listening(self):
        if self.is_listening:
            self.stop_listening()
        else:
            self.start_listening()

    def start_listening(self):
        self.is_listening = True
        self.visualizer_active = True
        self.btn_listen.config(text="🛑 STOP LISTENING", bg="#dc2626")
        self.set_status("Listening...", "#ef4444")
        self._animate_waveform()
        threading.Thread(target=self._capture_audio_worker, daemon=True).start()

    def stop_listening(self):
        self.is_listening = False
        self.visualizer_active = False
        self.btn_listen.config(text="🎙️ START LISTENING", bg="#2563eb")
        self.set_status("Ready", "#10b981")
        self._draw_idle_waveform()

    def _capture_audio_worker(self):
        # Attempt microphone capture via SpeechRecognition if library and mic are available
        rec_text = None
        try:
            import speech_recognition as sr
            r = sr.Recognizer()
            with sr.Microphone() as source:
                r.adjust_for_ambient_noise(source, duration=0.6)
                audio = r.listen(source, timeout=4, phrase_time_limit=6)
                rec_text = r.recognize_google(audio)
        except Exception:
            # If no microphone / library, provide interactive prompt simulation
            rec_text = None

        self.root.after(0, self._on_audio_captured, rec_text)

    def _on_audio_captured(self, text):
        self.stop_listening()
        if text:
            self.execute_prompt(text)
        else:
            msg = "Could not capture speech via microphone. Please type your query in the box or click a quick prompt."
            self.append_log("System", msg, tag="sys")

    def on_text_submit(self):
        text = self.cmd_entry.get().strip()
        if text:
            self.cmd_entry.delete(0, tk.END)
            self.execute_prompt(text)

    def execute_prompt(self, query):
        if not query:
            return
        self.append_log("User", query, tag="user")
        self.set_status("Thinking...", "#f59e0b")

        # Process command in background thread
        threading.Thread(target=self._process_command_worker, args=(query,), daemon=True).start()

    def _process_command_worker(self, query):
        clean_q = query.lower().strip()
        response = None
        action = None

        # Check custom rules first
        for key, val in self.custom_commands.items():
            if key.lower() in clean_q:
                response = val
                break

        # Standard built-in intents
        if not response:
            if any(w in clean_q for w in ["hello", "hi", "hey", "namaste", "halo"]):
                greetings = [
                    "Hello! How are you doing today?",
                    "Hi there! How can I assist you?",
                    "Hey! Always happy to help."
                ]
                response = random.choice(greetings)

            elif "time" in clean_q:
                now_str = datetime.datetime.now().strftime("%I:%M %p")
                response = f"The current time is {now_str}."

            elif any(w in clean_q for w in ["date", "day", "today"]):
                today_str = datetime.datetime.now().strftime("%A, %B %d, %Y")
                response = f"Today is {today_str}."

            elif "weather" in clean_q:
                # Provide a live condition or accurate simulated report
                response = self._get_quick_weather(clean_q)

            elif "search" in clean_q or "google" in clean_q or "browse" in clean_q:
                # Extract search term
                search_term = query
                for prefix in ["search for", "search", "google", "browse for", "browse"]:
                    if clean_q.startswith(prefix):
                        search_term = query[len(prefix):].strip()
                        break
                web_url = f"https://www.google.com/search?q={search_term}"
                action = lambda: webbrowser.open(web_url)
                response = f"Opening Google search for '{search_term}' in your browser."

            elif "remind" in clean_q:
                response = self._schedule_reminder(clean_q)

            elif "email" in clean_q or "mail" in clean_q:
                response = "Email module simulated: Composed email message with Subject 'Oasis Infobyte Task Update'. In production, smtplib credentials send this securely."

            elif "joke" in clean_q:
                jokes = [
                    "Why do Java programmers wear glasses? Because they don't C#!",
                    "There are 10 types of people in the world: those who understand binary, and those who don't.",
                    "A SQL query walks into a bar, walks up to two tables and asks: 'Can I join you?'"
                ]
                response = random.choice(jokes)

            elif "oasis" in clean_q or "infobyte" in clean_q or "internship" in clean_q:
                response = "Oasis Infobyte (OIBSIP) is a recognized platform providing practical domain experience for students worldwide across Web Dev, Python, Data Science, and more."

            else:
                # Fallback web search prompt
                web_url = f"https://www.google.com/search?q={query}"
                action = lambda: webbrowser.open(web_url)
                response = f"I found some information online for '{query}'. Opening in your web browser."

        # Update GUI and speak
        self.root.after(0, self._render_response, response, action)

    def _render_response(self, response, action):
        self.append_log("Aura", response, tag="aura")
        self.set_status("Speaking...", "#38bdf8")

        # Execute auxiliary action (e.g. web browser)
        if action:
            try:
                action()
            except Exception as e:
                print(f"Action error: {e}")

        # Speak via TTS
        def _speak_and_reset():
            self.tts.speak(response)
            self.root.after(0, lambda: self.set_status("Ready", "#10b981"))

        threading.Thread(target=_speak_and_reset, daemon=True).start()

    def _get_quick_weather(self, query):
        # Quick weather lookup or smart fallback
        try:
            import urllib.request
            # Try wttr.in format=3 for instant plain text weather
            req = urllib.request.Request("https://wttr.in/?format=3", headers={'User-Agent': 'curl/7.68.0'})
            with urllib.request.urlopen(req, timeout=3) as resp:
                data = resp.read().decode('utf-8').strip()
                if data:
                    return f"Current weather update: {data}"
        except Exception:
            pass
        return "The weather today is pleasant with partly cloudy skies and a comfortable temperature around 26°C."

    def _schedule_reminder(self, text):
        # Parses e.g. "remind me in 10 seconds to drink water"
        import re
        match = re.search(r"(\d+)\s*(second|sec|minute|min)", text)
        duration = 5
        unit = "seconds"
        if match:
            val = int(match.group(1))
            unit_str = match.group(2)
            if "min" in unit_str:
                duration = val * 60
                unit = "minutes"
            else:
                duration = val
                unit = "seconds"

        due_time = time.time() + duration
        rem_text = text.replace("remind me in", "").strip()
        self.reminders.append({"due": due_time, "text": rem_text, "active": True})
        return f"Got it! I set a reminder for {duration} {unit} from now: '{rem_text}'."

    def _start_reminder_checker(self):
        def _checker():
            now = time.time()
            for r in self.reminders:
                if r["active"] and now >= r["due"]:
                    r["active"] = False
                    alert_msg = f"🔔 REMINDER ALERT: {r['text']}!"
                    self.root.after(0, lambda m=alert_msg: self.append_log("Alert", m, tag="alert"))
                    self.root.after(0, lambda m=alert_msg: self.tts.speak(m))
            self.root.after(1000, self._start_reminder_checker)

        self.root.after(1000, _checker)

    # --- Custom Command Editor Dialog ---
    def open_custom_command_dialog(self):
        dialog = tk.Toplevel(self.root)
        dialog.title("Custom Commands Configuration")
        dialog.geometry("520x420")
        dialog.configure(bg="#1e293b")
        dialog.transient(self.root)
        dialog.grab_set()

        lbl = tk.Label(dialog, text="Add / View Custom Voice Commands", font=("Segoe UI", 12, "bold"), fg="#38bdf8", bg="#1e293b")
        lbl.pack(pady=10)

        frame = tk.Frame(dialog, bg="#1e293b")
        frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=5)

        tk.Label(frame, text="Spoken Trigger Phrase:", font=("Segoe UI", 9, "bold"), fg="#e2e8f0", bg="#1e293b").grid(row=0, column=0, sticky="w", pady=4)
        entry_trigger = tk.Entry(frame, font=("Segoe UI", 10), bg="#0b1329", fg="white", insertbackground="white")
        entry_trigger.grid(row=0, column=1, sticky="ew", pady=4, padx=5)

        tk.Label(frame, text="Assistant Response:", font=("Segoe UI", 9, "bold"), fg="#e2e8f0", bg="#1e293b").grid(row=1, column=0, sticky="w", pady=4)
        entry_resp = tk.Entry(frame, font=("Segoe UI", 10), bg="#0b1329", fg="white", insertbackground="white")
        entry_resp.grid(row=1, column=1, sticky="ew", pady=4, padx=5)
        frame.columnconfigure(1, weight=1)

        tree = ttk.Treeview(dialog, columns=("trigger", "response"), show="headings", height=8)
        tree.heading("trigger", text="Trigger Phrase")
        tree.heading("response", text="Response")
        tree.column("trigger", width=160)
        tree.column("response", width=300)
        tree.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)

        for k, v in self.custom_commands.items():
            tree.insert("", tk.END, values=(k, v))

        def add_rule():
            trig = entry_trigger.get().strip().lower()
            rsp = entry_resp.get().strip()
            if not trig or not rsp:
                messagebox.showwarning("Input Error", "Both trigger and response are required.", parent=dialog)
                return
            self.custom_commands[trig] = rsp
            save_custom_commands(self.custom_commands)
            tree.insert("", tk.END, values=(trig, rsp))
            entry_trigger.delete(0, tk.END)
            entry_resp.delete(0, tk.END)
            messagebox.showinfo("Success", f"Custom command '{trig}' saved successfully!", parent=dialog)

        btn_add = tk.Button(dialog, text="➕ Add Custom Rule", font=("Segoe UI", 10, "bold"), bg="#10b981", fg="white", relief=tk.FLAT, command=add_rule)
        btn_add.pack(pady=(0, 15))


if __name__ == "__main__":
    root = tk.Tk()
    app = VoiceAssistantApp(root)
    root.mainloop()
