# OIBSIP — Python Programming Task 1: AI Voice Assistant (Advanced Tier)

![Python](https://img.shields.io/badge/Python-3.8%2B-blue.svg)
![Tkinter](https://img.shields.io/badge/GUI-Tkinter-green.svg)
![Voice](https://img.shields.io/badge/Audio-SAPI%20%2F%20pyttsx3-purple.svg)
![Status](https://img.shields.io/badge/Status-Completed-success.svg)

---

## 📌 Project Overview
**Aura** is a modern, responsive, and feature-rich AI Voice Assistant built in Python. Designed for the Oasis Infobyte SIP Python Programming track, this project fulfills both **Beginner** and **Advanced Tier** requirements.

It features speech recognition, zero-latency text-to-speech synthesis (via Windows SAPI.SpVoice / pyttsx3 fallback), an animated audio visualizer waveform, web query dispatch, live weather intelligence, customizable intent rules, and interactive desktop reminders.

---

## ✨ Features Checklist

### Beginner Tier
- [x] **Voice & Typed Command Capture**: Captures speech input with intelligent fallback to clean typed commands.
- [x] **Natural Predefined Greetings**: Responsive dialogue for "Hello", "Hi", "Hey", etc.
- [x] **Date & Time Announcements**: Accurate real-time date, day, and time reporting.
- [x] **Automated Web Searches**: Instant query dispatch to the user's default browser (Google Search).
- [x] **Graceful Error Handling**: Non-blocking failure recovery when audio cannot be captured.
- [x] **Text-to-Speech (TTS) Feedback**: Clear spoken audio output for all assistant responses.

### Advanced Tier
- [x] **Natural Language Understanding (NLU)**: Intent parsing for greetings, reminders, weather, queries, jokes, and web searches.
- [x] **Email Dispatch Simulation**: Integrated email composer format following `smtplib` architecture.
- [x] **Timed Reminders with Audio Alert**: Asynchronous countdown timers that trigger sound and on-screen alerts.
- [x] **Live Weather Updates**: Automated weather polling with live condition descriptions and temperature.
- [x] **General Knowledge Q&A**: Built-in knowledge base with dynamic online web fallback.
- [x] **Custom Command Engine**: Persistent JSON configuration editor allowing users to add custom trigger-response rules via GUI.
- [x] **Modern Visualizer GUI**: Dark-themed UI with real-time animated dual-sine audio waveform monitor.
- [x] **Data Privacy Transparency**: Explicit documentation of data processing guarantees.

---

## 🔒 Data Privacy & Security Consideration
- **In-Memory Audio Processing**: Voice streams are handled strictly in volatile RAM memory during processing. No user audio is recorded or persisted to the hard drive.
- **No Third-Party Tracking**: User queries and speech inputs are not sent to any telemetry or ad-tracking endpoints.
- **Local Storage**: All custom command mappings and settings are stored locally in `custom_commands.json` on the client machine.

---

## 🚀 How to Run

### Prerequisites
Make sure Python 3.8+ is installed on your machine.
```bash
# Optional dependencies (if not already installed)
pip install pyttsx3 SpeechRecognition requests
```

### Execution
Run the standalone assistant script:
```bash
python voice_assistant.py
```

---

## 📹 Screen Recording Walkthrough Script (for Task Submission)

> **⚠️ OASIS INFOBYTE REQUIREMENT**: The video must begin with a clear 2-second static title card displaying:
> 1. Full Name
> 2. Assigned Track: **Python Programming**
> 3. Task Title: **Task 1 - Voice Assistant**

### Video Step-by-Step Flow:
1. **[0:00 - 0:02]** Static title card showing Name, Track, and Task Title.
2. **[0:03 - 0:10]** Launch `voice_assistant.py`. Welcome greeting speaks automatically with waveform animation.
3. **[0:11 - 0:25]** Click "🕒 Current Time" or say "What time is it?". Assistant speaks and logs the response.
4. **[0:26 - 0:40]** Click "🌤️ Weather Report". Demonstrates weather fetching.
5. **[0:41 - 0:55]** Click "⏰ Set 5s Reminder". Show the live background countdown timer and popup chime alert!
6. **[0:56 - 1:15]** Click "💡 Add Custom Rule". Add a custom phrase (e.g. `who is the best intern`) and response, then trigger it live!
7. **[1:16 - 1:30]** Conclude showing the clear log, privacy note, and smooth UI.

---

## 💼 LinkedIn Submission Post Template

```text
Excited to share that I have completed Task 1: "AI Voice Assistant" as part of my Python Programming Internship at Oasis Infobyte (OIBSIP)! 🚀

Project: Aura - Intelligent Voice & Desktop Assistant
Tech Stack: Python, Tkinter, SAPI.SpVoice / pyttsx3, SpeechRecognition, Threading, JSON

Key Features Implemented:
✨ Real-time voice & text command processing with speech synthesis
✨ Animated dual-wave audio visualizer monitor
✨ Live weather reporting, time/date alerts, and automated web searches
✨ Timed background reminders with audio alert popups
✨ Dynamic custom command configuration engine with persistent JSON storage
✨ High-security in-memory privacy architecture

Check out my GitHub repository for the full source code:
🔗 https://github.com/YOUR_USERNAME/OIBSIP

Thank you @Oasis Infobyte for this wonderful learning opportunity!

#oasisinfobyte #internship #python #voiceassistant #gui #softwaredevelopment #programming #ai
```
